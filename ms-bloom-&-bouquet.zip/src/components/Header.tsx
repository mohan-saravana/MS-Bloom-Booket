import React from 'react';
import { ShoppingBag, Flower, ClipboardList } from 'lucide-react';

interface HeaderProps {
  activeTab: 'shop' | 'builder' | 'cart' | 'orders' | 'occasions' | 'glossary' | 'about';
  setActiveTab: (tab: 'shop' | 'builder' | 'cart' | 'orders' | 'occasions' | 'glossary' | 'about') => void;
  cartCount: number;
}

export default function Header({ activeTab, setActiveTab, cartCount }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-stone-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between py-4 md:py-0 md:h-20">
          
          <div className="flex items-center justify-between w-full md:w-auto">
            {/* Logo and Branding */}
            <div 
              className="flex items-center gap-2.5 cursor-pointer group"
              id="logo-container"
              onClick={() => setActiveTab('shop')}
            >
              <div className="w-10 h-10 rounded-full bg-amber-50 flex items-center justify-center text-amber-600 transition-transform group-hover:rotate-12 border border-amber-100">
                <Flower className="w-5.5 h-5.5 stroke-[1.5]" />
              </div>
              <div>
                <span className="font-serif text-lg sm:text-xl tracking-wide font-semibold text-stone-800">
                  MS Bloom & Bouquet
                </span>
                <p className="text-[10px] font-mono tracking-widest text-stone-400 uppercase">
                  Artisanal Floristry
                </p>
              </div>
            </div>

            {/* Mobile / Desk Cart triggers */}
            <div className="flex items-center gap-2 md:hidden">
              <button
                id="cart-trigger-btn-mobile"
                onClick={() => setActiveTab('cart')}
                className={`relative p-2 rounded-full border border-stone-100 transition-all ${
                  activeTab === 'cart'
                    ? 'bg-amber-50 border-amber-200 text-amber-700'
                    : 'bg-stone-50 hover:bg-stone-100 text-stone-600 hover:text-stone-800'
                }`}
                aria-label="Shopping Cart"
              >
                <ShoppingBag className="w-5 h-5 stroke-[1.75]" />
                {cartCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 bg-rose-600 text-white text-[10px] font-semibold w-5 h-5 rounded-full flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </button>
            </div>
          </div>

          {/* Navigation Items - Scrollable on mobile */}
          <nav className="flex items-center gap-2 sm:gap-4 overflow-x-auto whitespace-nowrap no-scrollbar -mx-4 px-4 mt-4 md:mt-0 md:mx-0 md:px-0 scrollbar-none py-1">
            <button
              id="nav-shop"
              onClick={() => setActiveTab('shop')}
              className={`font-serif text-xs sm:text-sm tracking-wide transition-all relative py-1 px-1.5 cursor-pointer ${
                activeTab === 'shop' 
                  ? 'text-amber-700 font-medium' 
                  : 'text-stone-500 hover:text-stone-800'
              }`}
            >
              Our Bouquets
              {activeTab === 'shop' && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-600 rounded-full" />
              )}
            </button>
            <button
              id="nav-builder"
              onClick={() => setActiveTab('builder')}
              className={`font-serif text-xs sm:text-sm tracking-wide transition-all relative py-1 px-1.5 cursor-pointer ${
                activeTab === 'builder' 
                  ? 'text-amber-700 font-medium' 
                  : 'text-stone-500 hover:text-stone-800'
              }`}
            >
              Custom Bouquet Builder
              {activeTab === 'builder' && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-600 rounded-full" />
              )}
            </button>
            <button
              id="nav-occasions"
              onClick={() => setActiveTab('occasions')}
              className={`font-serif text-xs sm:text-sm tracking-wide transition-all relative py-1 px-1.5 cursor-pointer ${
                activeTab === 'occasions' 
                  ? 'text-amber-700 font-medium' 
                  : 'text-stone-500 hover:text-stone-800'
              }`}
            >
              Gift Finder
              {activeTab === 'occasions' && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-600 rounded-full" />
              )}
            </button>
            <button
              id="nav-glossary"
              onClick={() => setActiveTab('glossary')}
              className={`font-serif text-xs sm:text-sm tracking-wide transition-all relative py-1 px-1.5 cursor-pointer ${
                activeTab === 'glossary' 
                  ? 'text-amber-700 font-medium' 
                  : 'text-stone-500 hover:text-stone-800'
              }`}
            >
              Stem Glossary
              {activeTab === 'glossary' && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-600 rounded-full" />
              )}
            </button>
            <button
              id="nav-orders"
              onClick={() => setActiveTab('orders')}
              className={`font-serif text-xs sm:text-sm tracking-wide transition-all relative py-1 px-1.5 flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'orders' 
                  ? 'text-amber-700 font-medium' 
                  : 'text-stone-500 hover:text-stone-800'
              }`}
            >
              <ClipboardList className="w-3.5 h-3.5 stroke-[1.5]" />
              Track Orders
              {activeTab === 'orders' && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-600 rounded-full" />
              )}
            </button>
            <button
              id="nav-about"
              onClick={() => setActiveTab('about')}
              className={`font-serif text-xs sm:text-sm tracking-wide transition-all relative py-1 px-1.5 cursor-pointer ${
                activeTab === 'about' 
                  ? 'text-amber-700 font-medium' 
                  : 'text-stone-500 hover:text-stone-800'
              }`}
            >
              About Us
              {activeTab === 'about' && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-600 rounded-full" />
              )}
            </button>
          </nav>

          {/* Cart Icon / Action for desktop only */}
          <div className="hidden md:flex items-center gap-4">
            <button
              id="cart-trigger-btn"
              onClick={() => setActiveTab('cart')}
              className={`relative p-2 rounded-full border border-stone-100 transition-all ${
                activeTab === 'cart'
                  ? 'bg-amber-50 border-amber-200 text-amber-700'
                  : 'bg-stone-50 hover:bg-stone-100 text-stone-600 hover:text-stone-800'
              }`}
              aria-label="Shopping Cart"
            >
              <ShoppingBag className="w-5 h-5 stroke-[1.75]" />
              {cartCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-rose-600 text-white text-[10px] font-semibold w-5 h-5 rounded-full flex items-center justify-center animate-bounce">
                  {cartCount}
                </span>
              )}
            </button>
          </div>

        </div>
      </div>
    </header>
  );
}
