import React from 'react';
import { Bouquet, Flower } from '../types';
import { FLOWERS } from '../data';
import { Sparkles, ShoppingBag, Eye } from 'lucide-react';

interface BouquetCardProps {
  key?: string | number;
  bouquet: Bouquet;
  onCustomize: (bouquet: Bouquet) => void;
  onAddToCart: (bouquet: Bouquet) => void;
}

export default function BouquetCard({ bouquet, onCustomize, onAddToCart }: BouquetCardProps) {
  // Map baseFlowers IDs to Flower names
  const flowerDetails = bouquet.baseFlowers.map(bf => {
    const flower = FLOWERS.find(f => f.id === bf.flowerId);
    return {
      name: flower ? flower.name : bf.flowerId,
      count: bf.count,
      color: flower ? flower.color : '#A1A1AA'
    };
  });

  return (
    <div 
      id={`bouquet-card-${bouquet.id}`} 
      className="bg-white rounded-3xl overflow-hidden border border-stone-100 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col group h-full"
    >
      {/* Image Container with Hover Zoom */}
      <div className="relative aspect-[4/3] overflow-hidden bg-stone-100">
        <img
          src={bouquet.imageUrl}
          alt={bouquet.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        {/* Category Tag */}
        <span className="absolute top-4 left-4 bg-white/90 backdrop-blur-md text-stone-700 text-[10px] font-mono tracking-widest uppercase px-3 py-1.5 rounded-full border border-stone-100 shadow-sm">
          {bouquet.category}
        </span>
      </div>

      {/* Content */}
      <div className="p-6 sm:p-7 flex flex-col flex-grow">
        <div className="flex justify-between items-start gap-3 mb-2">
          <h3 className="font-serif text-lg sm:text-xl font-semibold text-stone-800 tracking-tight group-hover:text-amber-800 transition-colors">
            {bouquet.name}
          </h3>
          <span className="font-serif text-base sm:text-lg font-bold text-amber-900 bg-amber-50/80 border border-amber-100/50 px-3 py-1 rounded-2xl whitespace-nowrap">
            ₹{bouquet.basePrice.toLocaleString('en-IN')}
          </span>
        </div>

        <p className="text-stone-500 text-xs sm:text-sm leading-relaxed mb-6 flex-grow">
          {bouquet.description}
        </p>

        {/* Flower Ingredients Badge List */}
        <div className="mb-6 bg-stone-50/50 rounded-2xl p-4 border border-stone-100/60">
          <span className="text-[10px] font-mono text-stone-400 uppercase tracking-wider block mb-2.5">
            Recipe Ingredients
          </span>
          <div className="flex flex-wrap gap-1.5">
            {flowerDetails.map((fd, i) => (
              <span 
                key={i} 
                className="inline-flex items-center gap-1.5 bg-white border border-stone-200/50 text-stone-600 text-[11px] px-2.5 py-1 rounded-full shadow-2sm"
              >
                <span 
                  className="w-2 h-2 rounded-full border border-black/5 flex-shrink-0" 
                  style={{ backgroundColor: fd.color }} 
                />
                <span className="font-medium text-stone-700">{fd.count}</span> {fd.name}
              </span>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-3 mt-auto">
          <button
            id={`customize-btn-${bouquet.id}`}
            onClick={() => onCustomize(bouquet)}
            className="flex items-center justify-center gap-1.5 text-xs font-serif tracking-wide py-3 px-4 rounded-2xl border border-stone-200 hover:border-amber-600 bg-white hover:bg-amber-50/20 text-stone-700 hover:text-amber-800 transition-all cursor-pointer font-medium shadow-sm hover:shadow-md"
          >
            <Sparkles className="w-4 h-4 text-amber-600 animate-pulse" />
            Add More Flowers
          </button>
          
          <button
            id={`buy-now-btn-${bouquet.id}`}
            onClick={() => onAddToCart(bouquet)}
            className="flex items-center justify-center gap-1.5 text-xs font-serif tracking-wide py-3 px-4 rounded-2xl bg-amber-700 hover:bg-amber-800 text-white transition-all cursor-pointer font-medium shadow-sm hover:shadow-md hover:translate-y-[-1px] active:translate-y-0"
          >
            <ShoppingBag className="w-4 h-4" />
            Buy Directly
          </button>
        </div>
      </div>
    </div>
  );
}
