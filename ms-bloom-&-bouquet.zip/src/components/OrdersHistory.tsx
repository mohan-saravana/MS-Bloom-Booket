import React from 'react';
import { Order, OrderStatus } from '../types';
import { FLOWERS, getBouquetImage } from '../data';
import { Truck, CheckCircle, PackageOpen, ClipboardList, HelpCircle, RefreshCw } from 'lucide-react';

interface OrdersHistoryProps {
  orders: Order[];
  onUpdateOrderStatus: (orderId: string, nextStatus: OrderStatus) => void;
  setActiveTab: (tab: 'shop' | 'builder' | 'cart' | 'orders') => void;
}

export default function OrdersHistory({ orders, onUpdateOrderStatus, setActiveTab }: OrdersHistoryProps) {
  
  // Progress calculations
  const getStatusStep = (status: OrderStatus) => {
    switch (status) {
      case 'placed': return 1;
      case 'assembling': return 2;
      case 'dispatched': return 3;
      case 'delivered': return 4;
      default: return 1;
    }
  };

  const getStatusColor = (status: OrderStatus) => {
    switch (status) {
      case 'placed': return 'text-amber-600 bg-amber-50 border-amber-200';
      case 'assembling': return 'text-rose-600 bg-rose-50 border-rose-200';
      case 'dispatched': return 'text-sky-600 bg-sky-50 border-sky-200';
      case 'delivered': return 'text-emerald-600 bg-emerald-50 border-emerald-200';
      default: return 'text-stone-600 bg-stone-50 border-stone-200';
    }
  };

  const getStatusLabel = (status: OrderStatus) => {
    switch (status) {
      case 'placed': return 'Order Placed';
      case 'assembling': return 'Florists Assembling Bouquet';
      case 'dispatched': return 'Out For Delivery';
      case 'delivered': return 'Delivered Fresh';
      default: return status;
    }
  };

  const getNextStatus = (currentStatus: OrderStatus): OrderStatus | null => {
    switch (currentStatus) {
      case 'placed': return 'assembling';
      case 'assembling': return 'dispatched';
      case 'dispatched': return 'delivered';
      case 'delivered': return null; // fully complete!
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 animate-fade-in" id="orders-dashboard">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-stone-100 pb-6 mb-8">
        <div>
          <h1 className="font-serif text-3xl font-semibold text-stone-800 tracking-tight">
            Track Your Bouquet Delivery
          </h1>
          <p className="text-stone-500 text-sm mt-1">
            Real-time status of your luxury fresh-cut arrangements.
          </p>
        </div>
        
        <button
          id="orders-go-shop"
          onClick={() => setActiveTab('shop')}
          className="py-2.5 px-4 rounded-xl border border-stone-200 hover:border-amber-600 bg-white text-stone-700 text-xs font-semibold hover:text-amber-800 font-serif transition-colors cursor-pointer"
        >
          Back to Flower Shop
        </button>
      </div>

      {orders.length === 0 ? (
        <div className="text-center py-20 bg-stone-50/50 rounded-3xl border border-stone-100/60 p-8" id="empty-orders-view">
          <div className="w-14 h-14 bg-white text-stone-300 rounded-full border border-stone-100 flex items-center justify-center mx-auto mb-5 shadow-2sm">
            <ClipboardList className="w-6 h-6 stroke-[1.25]" />
          </div>
          <h2 className="font-serif text-xl font-semibold text-stone-800 mb-1.5">No active orders found</h2>
          <p className="text-stone-500 text-xs sm:text-sm max-w-sm mx-auto mb-6 leading-relaxed">
            You haven't purchased any bouquets yet. Check out our store catalogue or build a customized bouquet with added flowers in Rupees (₹) to see live tracking!
          </p>
          <button
            id="orders-shop-action"
            onClick={() => setActiveTab('shop')}
            className="py-3 px-6 rounded-2xl bg-amber-700 hover:bg-amber-800 text-white font-serif text-xs font-semibold tracking-wide transition-all shadow-sm cursor-pointer"
          >
            Order Your First Bouquet
          </button>
        </div>
      ) : (
        <div className="space-y-8" id="orders-list">
          {orders.map((order) => {
            const currentStep = getStatusStep(order.status);
            const nextStatus = getNextStatus(order.status);

            return (
              <div 
                key={order.id}
                id={`order-card-${order.id}`}
                className="bg-white border border-stone-150 rounded-3xl p-6 sm:p-8 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden"
              >
                {/* Header info bar */}
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 pb-5 border-b border-stone-100 mb-6">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2.5">
                      <span className="font-mono text-xs font-bold text-stone-400 uppercase tracking-wider">
                        ORDER ID: #{order.id}
                      </span>
                      <span className={`text-[10px] font-mono tracking-widest font-bold uppercase border px-2.5 py-1 rounded-full ${getStatusColor(order.status)}`}>
                        {getStatusLabel(order.status)}
                      </span>
                    </div>
                    <p className="text-xs text-stone-500 font-medium">
                      Ordered: {order.orderDate} • Target Delivery: <strong className="text-stone-700 font-semibold">{order.deliveryDate}</strong>
                    </p>
                  </div>

                  <div className="text-left sm:text-right">
                    <span className="text-[10px] font-mono text-stone-400 block uppercase">Total Rupees Paid</span>
                    <span className="font-serif text-xl font-bold text-amber-900 font-mono">
                      ₹{order.total.toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>

                {/* Progress Visual Tracker */}
                <div className="mb-8">
                  <div className="relative flex items-center justify-between">
                    {/* Background Progress line */}
                    <div className="absolute left-0 right-0 top-1/2 -translate-y-1/2 h-1 bg-stone-100 -z-10" />
                    
                    {/* Active Progress line */}
                    <div 
                      className="absolute left-0 top-1/2 -translate-y-1/2 h-1 bg-amber-600 -z-10 transition-all duration-700"
                      style={{ width: `${((currentStep - 1) / 3) * 100}%` }}
                    />

                    {/* Step 1: Placed */}
                    <div className="flex flex-col items-center">
                      <div className={`w-9 h-9 rounded-full flex items-center justify-center border-2 transition-all font-mono text-xs font-bold ${
                        currentStep >= 1 
                          ? 'bg-amber-600 border-amber-600 text-white' 
                          : 'bg-white border-stone-200 text-stone-400'
                      }`}>
                        1
                      </div>
                      <span className={`text-[10px] sm:text-xs font-serif mt-2 font-medium ${currentStep >= 1 ? 'text-amber-800' : 'text-stone-400'}`}>
                        Confirmed
                      </span>
                    </div>

                    {/* Step 2: Assembling */}
                    <div className="flex flex-col items-center">
                      <div className={`w-9 h-9 rounded-full flex items-center justify-center border-2 transition-all font-mono text-xs font-bold ${
                        currentStep >= 2 
                          ? 'bg-amber-600 border-amber-600 text-white' 
                          : 'bg-white border-stone-200 text-stone-400'
                      }`}>
                        2
                      </div>
                      <span className={`text-[10px] sm:text-xs font-serif mt-2 font-medium ${currentStep >= 2 ? 'text-amber-800' : 'text-stone-400'}`}>
                        Assembling
                      </span>
                    </div>

                    {/* Step 3: Dispatched */}
                    <div className="flex flex-col items-center">
                      <div className={`w-9 h-9 rounded-full flex items-center justify-center border-2 transition-all font-mono text-xs font-bold ${
                        currentStep >= 3 
                          ? 'bg-amber-600 border-amber-600 text-white' 
                          : 'bg-white border-stone-200 text-stone-400'
                      }`}>
                        3
                      </div>
                      <span className={`text-[10px] sm:text-xs font-serif mt-2 font-medium ${currentStep >= 3 ? 'text-amber-800' : 'text-stone-400'}`}>
                        In Transit
                      </span>
                    </div>

                    {/* Step 4: Delivered */}
                    <div className="flex flex-col items-center">
                      <div className={`w-9 h-9 rounded-full flex items-center justify-center border-2 transition-all font-mono text-xs font-bold ${
                        currentStep >= 4 
                          ? 'bg-emerald-600 border-emerald-600 text-white shadow-sm' 
                          : 'bg-white border-stone-200 text-stone-400'
                      }`}>
                        ✓
                      </div>
                      <span className={`text-[10px] sm:text-xs font-serif mt-2 font-medium ${currentStep >= 4 ? 'text-emerald-800' : 'text-stone-400'}`}>
                        Delivered
                      </span>
                    </div>
                  </div>
                </div>

                {/* Grid layout of order content list */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 pt-2">
                  <div className="md:col-span-7 space-y-3.5">
                    <span className="text-[10px] font-mono text-stone-400 uppercase tracking-widest block">
                      Arrangement Details
                    </span>
                    
                    {order.items.map((item, index) => (
                      <div key={index} className="flex gap-4 items-start bg-stone-50/50 p-4 rounded-2xl border border-stone-100">
                        {/* Thumbnail mini */}
                        <div className="w-12 h-12 rounded-xl bg-stone-100 overflow-hidden flex-shrink-0 border border-stone-200/50">
                          <img
                            src={getBouquetImage(item.baseBouquet, item.addedFlowers)}
                            alt={item.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="text-xs">
                          <h4 className="font-serif font-semibold text-stone-800">{item.name} x {item.quantity}</h4>
                          <p className="text-stone-500 mt-1">
                            {Object.entries(item.addedFlowers)
                              .map(([fid, count]) => {
                                const f = FLOWERS.find(fl => fl.id === fid);
                                return f ? `${count} ${f.name}` : null;
                              })
                              .filter(Boolean)
                              .join(', ')}
                          </p>
                          {item.cardMessage && (
                            <p className="text-amber-800 italic font-medium mt-1">
                              Card: "{item.cardMessage}"
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="md:col-span-5 space-y-4 bg-stone-50 rounded-2xl p-5 border border-stone-100 text-xs">
                    <span className="text-[10px] font-mono text-stone-400 uppercase tracking-widest block">
                      Delivery Logistics
                    </span>
                    
                    <div className="space-y-2.5">
                      <div>
                        <span className="text-stone-400">Recipient Name</span>
                        <p className="font-semibold text-stone-800">{order.customerName}</p>
                      </div>
                      <div>
                        <span className="text-stone-400">Recipient Mobile</span>
                        <p className="font-semibold text-stone-800">{order.phoneNumber}</p>
                      </div>
                      <div>
                        <span className="text-stone-400">Delivery Address</span>
                        <p className="font-semibold text-stone-800 leading-normal">{order.deliveryAddress}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* SIMULATOR TOOL (Interactive simulation of delivery status) */}
                {nextStatus && (
                  <div className="mt-6 pt-4 border-t border-stone-100 flex items-center justify-between flex-wrap gap-2.5">
                    <div className="flex items-center gap-1.5 text-stone-400">
                      <RefreshCw className="w-3.5 h-3.5 text-amber-600 animate-spin" />
                      <span className="text-[10px] font-mono">Development Simulator: Test tracking stages</span>
                    </div>
                    <button
                      id={`simulate-btn-${order.id}`}
                      onClick={() => onUpdateOrderStatus(order.id, nextStatus)}
                      className="py-1.5 px-3 bg-stone-900 text-amber-400 font-mono text-[10px] font-bold rounded-lg hover:bg-stone-850 transition-colors shadow-2sm cursor-pointer"
                    >
                      Advance Stage to: {getStatusLabel(nextStatus)}
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
