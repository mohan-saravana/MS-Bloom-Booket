import { useState, FormEvent } from 'react';
import { CartItem, Order, WrappingType } from '../types';
import { FLOWERS, WRAPPING_OPTIONS, getBouquetImage } from '../data';
import { Trash2, Plus, Minus, CreditCard, Landmark, Truck, ShieldCheck, Heart, Sparkles, ShoppingBag } from 'lucide-react';

interface CartViewProps {
  cart: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onPlaceOrder: (order: Order) => void;
  setActiveTab: (tab: 'shop' | 'builder' | 'cart' | 'orders') => void;
}

export default function CartView({ cart, onUpdateQuantity, onRemoveItem, onPlaceOrder, setActiveTab }: CartViewProps) {
  // Checkout form states
  const [customerName, setCustomerName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [address, setAddress] = useState('');
  const [pincode, setPincode] = useState('');
  const [deliveryDate, setDeliveryDate] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'cod'>('upi');
  
  // Checkout button state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isOrderSuccess, setIsOrderSuccess] = useState<Order | null>(null);

  // Totals
  const subtotal = cart.reduce((sum, item) => sum + item.totalPrice * item.quantity, 0);
  const deliveryFee = subtotal > 1500 || subtotal === 0 ? 0 : 150; // Free delivery above ₹1500
  const finalTotal = subtotal + deliveryFee;

  // Render detail text for customized items
  const getItemDetailsText = (item: CartItem) => {
    const details: string[] = [];

    // Wrapping
    const wrappingOption = WRAPPING_OPTIONS.find(w => w.id === item.wrapping);
    if (wrappingOption) {
      details.push(`Wrapped in ${wrappingOption.name}`);
    }

    // Flowers added
    const extraStemsText: string[] = [];
    Object.entries(item.addedFlowers).forEach(([flowerId, count]) => {
      const flower = FLOWERS.find(f => f.id === flowerId);
      if (flower) {
        // If there was a base bouquet, check what is "extra" versus standard
        let baseCount = 0;
        if (item.baseBouquet) {
          const baseItem = item.baseBouquet.baseFlowers.find(bf => bf.flowerId === flowerId);
          baseCount = baseItem ? baseItem.count : 0;
        }

        const extra = Math.max(0, count - baseCount);
        if (extra > 0) {
          extraStemsText.push(`${extra} extra ${flower.name}`);
        } else if (count > 0 && !item.baseBouquet) {
          // Fully custom from scratch
          extraStemsText.push(`${count} ${flower.name}`);
        }
      }
    });

    if (extraStemsText.length > 0) {
      details.push(`Includes: ${extraStemsText.join(', ')}`);
    }

    if (item.cardMessage.trim()) {
      details.push(`With gift card message: "${item.cardMessage}"`);
    }

    return details;
  };

  const handleCheckoutSubmit = (e: FormEvent) => {
    e.preventDefault();

    if (cart.length === 0) return;
    if (!customerName || !phoneNumber || !address || !deliveryDate) {
      alert('Please fill in all the required delivery details.');
      return;
    }

    setIsSubmitting(true);

    // Simulate ordering latency
    setTimeout(() => {
      const orderId = `ORD-${Math.floor(100000 + Math.random() * 900000)}`;
      
      // Calculate delivery estimate
      const today = new Date();
      const deliveryEst = new Date(deliveryDate);
      
      const newOrder: Order = {
        id: orderId,
        items: [...cart],
        customerName,
        deliveryAddress: `${address}, PIN: ${pincode}`,
        phoneNumber,
        cardMessage: cart.map(item => item.cardMessage).filter(Boolean).join(' | '),
        subtotal,
        deliveryFee,
        total: finalTotal,
        status: 'placed',
        orderDate: today.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }),
        deliveryDate: deliveryEst.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }),
      };

      onPlaceOrder(newOrder);
      setIsOrderSuccess(newOrder);
      setIsSubmitting(false);
    }, 1500);
  };

  // Success screen
  if (isOrderSuccess) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center animate-fade-in" id="order-success-screen">
        <div className="w-20 h-20 rounded-full bg-emerald-50 text-emerald-600 border border-emerald-100 flex items-center justify-center mx-auto mb-6">
          <Sparkles className="w-10 h-10 animate-pulse" />
        </div>
        
        <span className="text-xs font-mono tracking-widest text-emerald-600 uppercase font-semibold block mb-2">
          Order Completed successfully
        </span>
        <h1 className="font-serif text-3xl font-bold text-stone-800 mb-2">
          Your bouquet is on its way!
        </h1>
        <p className="text-stone-500 text-sm mb-6 leading-relaxed">
          Thank you, <strong className="text-stone-800 font-semibold">{isOrderSuccess.customerName}</strong>. We have received your payment of <strong className="text-amber-800">₹{isOrderSuccess.total.toLocaleString('en-IN')}</strong> in full. Our master florists are already selecting the finest petals for your arrangement.
        </p>

        {/* Order Details box */}
        <div className="bg-stone-50 rounded-2xl p-6 border border-stone-100 text-left mb-8 space-y-3">
          <div className="flex justify-between border-b border-stone-200 pb-2">
            <span className="text-xs font-mono text-stone-400 uppercase">Order ID</span>
            <span className="text-xs font-mono font-bold text-stone-700">{isOrderSuccess.id}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-xs text-stone-500">Scheduled Delivery</span>
            <span className="text-xs font-semibold text-stone-700">{isOrderSuccess.deliveryDate}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-xs text-stone-500">Destination</span>
            <span className="text-xs text-stone-700 max-w-[200px] text-right truncate">{isOrderSuccess.deliveryAddress}</span>
          </div>
          <div className="flex justify-between border-t border-stone-200/60 pt-2 text-stone-500">
            <span className="text-xs">Payment Method</span>
            <span className="text-xs font-semibold text-stone-700">
              {paymentMethod === 'upi' ? 'UPI / Paytm' : paymentMethod === 'card' ? 'Credit / Debit Card' : 'Cash on Delivery (COD)'}
            </span>
          </div>
          <div className="flex justify-between border-t border-stone-200 pt-2 font-bold">
            <span className="text-sm font-serif">Total Charged</span>
            <span className="text-sm font-mono text-amber-900">₹{isOrderSuccess.total.toLocaleString('en-IN')}</span>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <button
            id="success-track-btn"
            onClick={() => setActiveTab('orders')}
            className="flex-1 py-3.5 px-6 rounded-2xl bg-amber-700 hover:bg-amber-800 text-white font-serif text-sm font-semibold tracking-wide transition-all shadow-sm cursor-pointer"
          >
            Track Delivery Status
          </button>
          <button
            id="success-shop-btn"
            onClick={() => setActiveTab('shop')}
            className="flex-1 py-3.5 px-6 rounded-2xl border border-stone-200 bg-white hover:bg-stone-50 text-stone-700 font-serif text-sm font-semibold tracking-wide transition-all cursor-pointer"
          >
            Continue Browsing
          </button>
        </div>
      </div>
    );
  }

  // Empty cart
  if (cart.length === 0) {
    return (
      <div className="max-w-xl mx-auto px-4 py-20 text-center" id="empty-cart-screen">
        <div className="w-16 h-16 bg-stone-50 text-stone-400 border border-stone-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <ShoppingBag className="w-7 h-7 stroke-[1.5]" />
        </div>
        <h2 className="font-serif text-2xl font-semibold text-stone-800 mb-2">
          Your floral basket is empty
        </h2>
        <p className="text-stone-500 text-xs sm:text-sm mb-8 max-w-sm mx-auto leading-relaxed">
          Select one of our beautiful pre-made bouquets, or use our customized florist workbench to design a bouquet and add extra flowers!
        </p>
        <div className="flex justify-center gap-4">
          <button
            id="empty-go-shop"
            onClick={() => setActiveTab('shop')}
            className="py-3 px-6 rounded-2xl bg-amber-700 hover:bg-amber-800 text-white font-serif text-sm font-semibold tracking-wide transition-all shadow-sm cursor-pointer"
          >
            Browse Catalog
          </button>
          <button
            id="empty-go-builder"
            onClick={() => setActiveTab('builder')}
            className="py-3 px-6 rounded-2xl border border-stone-200 hover:border-amber-600 bg-white hover:bg-amber-50/20 text-stone-700 font-serif text-sm font-semibold tracking-wide transition-all cursor-pointer"
          >
            Design Custom Bouquet
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in" id="cart-workspace">
      <div className="mb-8">
        <h1 className="font-serif text-3xl font-semibold text-stone-800 tracking-tight">
          Your Floral Selection
        </h1>
        <p className="text-stone-500 text-sm mt-1">
          Review your hand-tailored flower bouquets and complete checkout securely below.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* CART LIST SECTION (Left) */}
        <div className="lg:col-span-7 space-y-4">
          
          {cart.map((item) => {
            const detailTexts = getItemDetailsText(item);
            
            return (
              <div 
                key={item.id}
                id={`cart-item-${item.id}`}
                className="bg-white border border-stone-100 rounded-3xl p-5 sm:p-6 shadow-2sm hover:shadow-sm transition-all flex flex-col sm:flex-row gap-5"
              >
                {/* Visual Thumbnail */}
                <div className="w-full sm:w-28 aspect-video sm:aspect-square bg-stone-50 border border-stone-100 rounded-2xl overflow-hidden flex-shrink-0">
                  <img
                    src={getBouquetImage(item.baseBouquet, item.addedFlowers)}
                    alt={item.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Content Details */}
                <div className="flex-grow space-y-2 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start gap-3">
                      <h3 className="font-serif text-base font-semibold text-stone-800 leading-tight">
                        {item.name}
                      </h3>
                      <span className="font-serif text-sm font-bold text-amber-900 whitespace-nowrap">
                        ₹{(item.totalPrice * item.quantity).toLocaleString('en-IN')}
                      </span>
                    </div>

                    {/* Meta descriptive rows */}
                    {detailTexts.length > 0 && (
                      <ul className="mt-2 space-y-1 text-[11px] sm:text-xs text-stone-500">
                        {detailTexts.map((text, idx) => (
                          <li key={idx} className="flex items-start gap-1.5 leading-normal">
                            <span className="text-amber-600 font-bold">•</span>
                            <span>{text}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>

                  {/* Adjust Quantity and Remove */}
                  <div className="flex items-center justify-between pt-4 border-t border-stone-100 mt-2">
                    <div className="flex items-center gap-2.5 bg-stone-50 border border-stone-200/60 rounded-xl p-1">
                      <button
                        id={`cart-minus-${item.id}`}
                        onClick={() => onUpdateQuantity(item.id, -1)}
                        className="w-6 h-6 bg-white text-stone-600 hover:bg-stone-100 rounded-lg flex items-center justify-center shadow-2sm cursor-pointer"
                        aria-label="Decrease quantity"
                      >
                        <Minus className="w-3" />
                      </button>
                      <span className="w-5 text-center font-mono text-xs font-semibold text-stone-800">
                        {item.quantity}
                      </span>
                      <button
                        id={`cart-plus-${item.id}`}
                        onClick={() => onUpdateQuantity(item.id, 1)}
                        className="w-6 h-6 bg-white text-stone-600 hover:bg-stone-100 rounded-lg flex items-center justify-center shadow-2sm cursor-pointer"
                        aria-label="Increase quantity"
                      >
                        <Plus className="w-3" />
                      </button>
                    </div>

                    <button
                      id={`cart-delete-${item.id}`}
                      onClick={() => onRemoveItem(item.id)}
                      className="text-stone-400 hover:text-rose-600 transition-colors p-2 hover:bg-rose-50 rounded-xl cursor-pointer"
                      title="Delete bouquet from cart"
                    >
                      <Trash2 className="w-4.5 h-4.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}

          <div className="bg-amber-50/50 border border-amber-100 rounded-2xl p-4 flex gap-3 items-center">
            <Heart className="w-5 h-5 text-amber-700 flex-shrink-0" />
            <p className="text-xs text-amber-800 leading-normal">
              Every arrangement is fresh-cut, packed beautifully in an insulated container, and comes with a 100% satisfaction guarantee.
            </p>
          </div>

        </div>

        {/* SECURE ONLINE CHECKOUT FORM (Right) */}
        <div className="lg:col-span-5 bg-stone-50 border border-stone-100 rounded-3xl p-6 sm:p-7 shadow-sm">
          <h2 className="font-serif text-lg font-semibold text-stone-800 mb-5 pb-3 border-b border-stone-200/60">
            Secure Buy Online
          </h2>

          <form onSubmit={handleCheckoutSubmit} className="space-y-4">
            <div>
              <label htmlFor="customer-name" className="block text-xs font-medium text-stone-500 mb-1">
                Recipient / Sender Name *
              </label>
              <input
                type="text"
                id="customer-name"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="Ex. Mohit Sharma"
                required
                className="w-full p-3 bg-white border border-stone-200 rounded-xl text-stone-700 text-xs sm:text-sm placeholder-stone-400 focus:outline-none focus:ring-1 focus:ring-amber-600 focus:border-amber-600"
              />
            </div>

            <div>
              <label htmlFor="customer-phone" className="block text-xs font-medium text-stone-500 mb-1">
                Contact Phone Number *
              </label>
              <input
                type="tel"
                id="customer-phone"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="Ex. +91 98765 43210"
                required
                className="w-full p-3 bg-white border border-stone-200 rounded-xl text-stone-700 text-xs sm:text-sm placeholder-stone-400 focus:outline-none focus:ring-1 focus:ring-amber-600 focus:border-amber-600"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-12 gap-4">
              <div className="sm:col-span-8">
                <label htmlFor="delivery-address" className="block text-xs font-medium text-stone-500 mb-1">
                  Full Delivery Address *
                </label>
                <input
                  type="text"
                  id="delivery-address"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Street, Apartment, Landmark"
                  required
                  className="w-full p-3 bg-white border border-stone-200 rounded-xl text-stone-700 text-xs sm:text-sm placeholder-stone-400 focus:outline-none focus:ring-1 focus:ring-amber-600 focus:border-amber-600"
                />
              </div>
              
              <div className="sm:col-span-4">
                <label htmlFor="pincode" className="block text-xs font-medium text-stone-500 mb-1">
                  Pincode *
                </label>
                <input
                  type="text"
                  id="pincode"
                  value={pincode}
                  onChange={(e) => setPincode(e.target.value)}
                  placeholder="110001"
                  maxLength={6}
                  required
                  className="w-full p-3 bg-white border border-stone-200 rounded-xl text-stone-700 text-xs sm:text-sm placeholder-stone-400 focus:outline-none focus:ring-1 focus:ring-amber-600 focus:border-amber-600"
                />
              </div>
            </div>

            <div>
              <label htmlFor="delivery-date" className="block text-xs font-medium text-stone-500 mb-1">
                Preferred Delivery Date *
              </label>
              <input
                type="date"
                id="delivery-date"
                value={deliveryDate}
                onChange={(e) => setDeliveryDate(e.target.value)}
                required
                min={new Date().toISOString().split('T')[0]}
                className="w-full p-3 bg-white border border-stone-200 rounded-xl text-stone-700 text-xs sm:text-sm text-stone-600 focus:outline-none focus:ring-1 focus:ring-amber-600 focus:border-amber-600"
              />
            </div>

            {/* Payment Method Selector */}
            <div className="pt-2">
              <span className="block text-xs font-medium text-stone-500 mb-2">Select Secure Payment Method</span>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  id="pay-upi"
                  onClick={() => setPaymentMethod('upi')}
                  className={`flex flex-col items-center p-3 rounded-2xl border transition-all text-center cursor-pointer ${
                    paymentMethod === 'upi'
                      ? 'bg-amber-100/30 border-amber-600 text-amber-900 shadow-2sm'
                      : 'bg-white border-stone-200 text-stone-600 hover:bg-stone-50'
                  }`}
                >
                  <Landmark className="w-5 h-5 mb-1 text-amber-700" />
                  <span className="text-[10px] font-semibold tracking-wide uppercase">UPI / PayTM</span>
                </button>

                <button
                  type="button"
                  id="pay-card"
                  onClick={() => setPaymentMethod('card')}
                  className={`flex flex-col items-center p-3 rounded-2xl border transition-all text-center cursor-pointer ${
                    paymentMethod === 'card'
                      ? 'bg-amber-100/30 border-amber-600 text-amber-900 shadow-2sm'
                      : 'bg-white border-stone-200 text-stone-600 hover:bg-stone-50'
                  }`}
                >
                  <CreditCard className="w-5 h-5 mb-1 text-amber-700" />
                  <span className="text-[10px] font-semibold tracking-wide uppercase">Card / Net</span>
                </button>

                <button
                  type="button"
                  id="pay-cod"
                  onClick={() => setPaymentMethod('cod')}
                  className={`flex flex-col items-center p-3 rounded-2xl border transition-all text-center cursor-pointer ${
                    paymentMethod === 'cod'
                      ? 'bg-amber-100/30 border-amber-600 text-amber-900 shadow-2sm'
                      : 'bg-white border-stone-200 text-stone-600 hover:bg-stone-50'
                  }`}
                >
                  <Truck className="w-5 h-5 mb-1 text-amber-700" />
                  <span className="text-[10px] font-semibold tracking-wide uppercase">COD (Cash)</span>
                </button>
              </div>

              {/* Dynamic Payment Method Fields */}
              {paymentMethod === 'upi' && (
                <div className="mt-3 bg-stone-50 border border-stone-200 rounded-2xl p-3 animate-fade-in text-left">
                  <p className="text-[11px] text-stone-600 leading-relaxed flex items-start gap-2">
                    <Landmark className="w-4 h-4 text-amber-750 flex-shrink-0 mt-0.5" />
                    <span>Pay instantly using any secure UPI app (Google Pay, PhonePe, Paytm, BHIM) upon delivery or order dispatch.</span>
                  </p>
                </div>
              )}

              {paymentMethod === 'card' && (
                <div className="mt-3 bg-stone-50 border border-stone-200 rounded-2xl p-3 animate-fade-in text-left">
                  <p className="text-[11px] text-stone-600 leading-relaxed flex items-start gap-2">
                    <CreditCard className="w-4 h-4 text-amber-750 flex-shrink-0 mt-0.5" />
                    <span>Secure processing supporting major Credit/Debit Cards (Visa, Mastercard, RuPay) and Net Banking.</span>
                  </p>
                </div>
              )}

              {paymentMethod === 'cod' && (
                <div className="mt-3 bg-stone-50 border border-stone-200 rounded-2xl p-3 animate-fade-in text-left">
                  <p className="text-[11px] text-stone-600 leading-relaxed flex items-start gap-2">
                    <Truck className="w-4 h-4 text-amber-755 flex-shrink-0 mt-0.5" />
                    <span>Pay with cash or scan our delivery executive's QR code when your handcrafted arrangement is delivered.</span>
                  </p>
                </div>
              )}
            </div>

            {/* Cost Recap Panel */}
            <div className="bg-white border border-stone-150 rounded-2xl p-4 mt-5 space-y-2 text-xs">
              <div className="flex justify-between text-stone-500">
                <span>Items Subtotal</span>
                <span className="font-mono text-stone-700">₹{subtotal.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between text-stone-500">
                <span>Safe Delivery Fee</span>
                <span className="font-mono text-stone-700">
                  {deliveryFee === 0 ? (
                    <span className="text-emerald-600 font-bold uppercase text-[10px]">FREE</span>
                  ) : (
                    `₹${deliveryFee}`
                  )}
                </span>
              </div>
              {deliveryFee > 0 && (
                <p className="text-[10px] text-stone-400 text-right leading-none">
                  Add ₹{Math.max(0, 1500 - subtotal)} more for Free Shipping!
                </p>
              )}
              <div className="flex justify-between pt-2 border-t border-stone-100 text-stone-800 font-bold text-sm">
                <span>Grand Total (Rupees)</span>
                <span className="font-mono text-amber-900 text-base">₹{finalTotal.toLocaleString('en-IN')}</span>
              </div>
            </div>

            {/* Final checkout button */}
            <button
              type="submit"
              id="submit-order-btn"
              disabled={isSubmitting}
              className={`w-full py-3.5 mt-2 rounded-2xl bg-amber-700 hover:bg-amber-800 text-white font-serif font-semibold tracking-wide text-sm transition-all shadow-md active:translate-y-0 cursor-pointer flex items-center justify-center gap-2 hover:scale-[1.01] ${
                isSubmitting ? 'opacity-70 pointer-events-none' : ''
              }`}
            >
              {isSubmitting ? (
                <>
                  <Sparkles className="w-5 h-5 animate-spin" />
                  Processing Safe Gateway Pay...
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4.5 h-4.5" />
                  Place Order & Pay ₹{finalTotal.toLocaleString('en-IN')}
                </>
              )}
            </button>
          </form>

        </div>

      </div>
    </div>
  );
}
