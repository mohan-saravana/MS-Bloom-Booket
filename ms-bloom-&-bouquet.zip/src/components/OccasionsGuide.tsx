import React, { useState } from 'react';
import { Gift, Heart, Sparkles, Smile, ArrowRight, MessageSquare, Copy } from 'lucide-react';
import { Bouquet } from '../types';
import { BOUQUETS } from '../data';

interface OccasionsGuideProps {
  onSelectOccasionPreset: (baseBouquet: Bouquet | null, presetMessage: string) => void;
  setActiveTab: (tab: 'shop' | 'builder' | 'cart' | 'orders' | 'occasions' | 'glossary' | 'about') => void;
}

interface OccasionTemplate {
  id: string;
  name: string;
  emoji: string;
  description: string;
  recommendedFlowers: string[];
  suggestedBouquetId: string;
  messages: string[];
}

const OCCASIONS: OccasionTemplate[] = [
  {
    id: 'romance',
    name: 'Love & Anniversary',
    emoji: '💖',
    description: 'Express timeless affection, passionate romance, or celebrate years of beautiful togetherness.',
    recommendedFlowers: ['Red Rose', 'Blush Pink Rose', 'Blossoming Pink Peony'],
    suggestedBouquetId: 'blushing_romance',
    messages: [
      "You make my heart and my world bloom in beautiful colors. Happy Anniversary, my love!",
      "To the one who completes my life with sweetness, here are fresh roses to match your grace.",
      "Every single day spent with you is like a garden in full spring bloom. I love you."
    ]
  },
  {
    id: 'birthday',
    name: 'Joyous Birthdays',
    emoji: '🎈',
    description: 'Wish them a bright, cheerful, and sunny year ahead with colorful joyful floral displays.',
    recommendedFlowers: ['Golden Sunflower', 'Orange Gerbera Daisy', 'Golden Tulip'],
    suggestedBouquetId: 'golden_grace',
    messages: [
      "Wishing you a sunny day as bright and magnificent as these sunflowers! Happy Birthday!",
      "May your year ahead be as vibrant, colorful, and joyful as this artisan flower bouquet!",
      "Celebrating another beautiful orbit around the sun. Sending you fresh blooms and warm hugs!"
    ]
  },
  {
    id: 'gratitude',
    name: 'Thank You & Gratitude',
    emoji: '🙏',
    description: 'Show deep appreciation, acknowledge kind favors, or say thank you to someone special.',
    recommendedFlowers: ['Pink Carnation', 'Blue Hydrangea', 'French Lavender Stem'],
    suggestedBouquetId: 'mystic_meadow',
    messages: [
      "I am incredibly grateful for your warmth, support, and guidance. Thank you so much!",
      "Words cannot express how thankful I am. Sending you these fresh hand-tied blooms with deepest gratitude.",
      "For everything you do, and the wonderful person you are — thank you from the bottom of my heart."
    ]
  },
  {
    id: 'healing',
    name: 'Get Well & Comfort',
    emoji: '🌿',
    description: 'Deliver comforting, soothing, and refreshing vibes to lift their spirits and wish speedy healing.',
    recommendedFlowers: ['Royal White Lily', 'Snow White Rose', 'Silver Eucalyptus'],
    suggestedBouquetId: 'royal_lily',
    messages: [
      "Sending you refreshing floral scents and warm healing thoughts. Get well soon, my dear friend!",
      "May these pure blossoms fill your room with peace, comfort, and gentle healing energy.",
      "Thinking of you during this time and wishing you a comfortable, peaceful, and rapid recovery."
    ]
  },
  {
    id: 'celebration',
    name: 'Festivals & Housewarming',
    emoji: '✨',
    description: 'Celebrate Indian festivals, new homes, promotions, or auspicious traditional beginnings.',
    recommendedFlowers: ['Golden Marigold (Genda) Stem', 'Imperial Purple Orchid', 'Golden Sunflower'],
    suggestedBouquetId: 'golden_grace',
    messages: [
      "May this new beginning bring immense peace, prosperity, and joy into your beautiful new home!",
      "Sending festive marigold warmth and bright sunflowers to bless your celebrations! Happy Festivities!",
      "Congratulations on your outstanding achievements! Wishing you absolute success and endless growth!"
    ]
  }
];

export default function OccasionsGuide({ onSelectOccasionPreset, setActiveTab }: OccasionsGuideProps) {
  const [selectedOccasion, setSelectedOccasion] = useState<OccasionTemplate>(OCCASIONS[0]);
  const [activeMessage, setActiveMessage] = useState<string>(OCCASIONS[0].messages[0]);
  const [copiedMessage, setCopiedMessage] = useState<boolean>(false);

  const handleOccasionChange = (occasion: OccasionTemplate) => {
    setSelectedOccasion(occasion);
    setActiveMessage(occasion.messages[0]);
    setCopiedMessage(false);
  };

  const handleCopy = (msg: string) => {
    navigator.clipboard.writeText(msg);
    setCopiedMessage(true);
    setTimeout(() => setCopiedMessage(false), 2000);
  };

  // Find corresponding pre-made bouquet
  const recommendedBouquet = BOUQUETS.find(b => b.id === selectedOccasion.suggestedBouquetId) || null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in" id="occasions-guide-page">
      <div className="text-center mb-10">
        <span className="text-[11px] font-mono tracking-widest text-amber-600 uppercase bg-amber-50 px-3 py-1.5 rounded-full border border-amber-100 font-semibold inline-block mb-3">
          Flower Gift Finder
        </span>
        <h1 className="font-serif text-3xl sm:text-4xl font-semibold text-stone-800 tracking-tight">
          Select Flowers by Occasion
        </h1>
        <p className="text-stone-500 text-sm max-w-2xl mx-auto mt-2.5">
          Not sure which stems to choose? Tell us what you are celebrating, and our master florist intelligence will recommend the perfect recipe and greeting message.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Occasions Selector Grid */}
        <div className="lg:col-span-5 space-y-4">
          <span className="text-[10px] font-mono text-stone-400 uppercase tracking-widest block pl-1">
            What is the Occasion?
          </span>

          <div className="space-y-3">
            {OCCASIONS.map((occ) => (
              <button
                key={occ.id}
                id={`occ-btn-${occ.id}`}
                onClick={() => handleOccasionChange(occ)}
                className={`w-full text-left p-4 rounded-3xl border transition-all flex gap-4 items-center cursor-pointer ${
                  selectedOccasion.id === occ.id
                    ? 'bg-amber-50/65 border-amber-500/60 shadow-2sm'
                    : 'bg-white border-stone-100 hover:border-stone-200 hover:bg-stone-50/50'
                }`}
              >
                <div className="w-12 h-12 rounded-2xl bg-white border border-stone-100 shadow-3sm flex items-center justify-center text-2xl flex-shrink-0">
                  {occ.emoji}
                </div>
                <div>
                  <h3 className="font-serif text-sm sm:text-base font-semibold text-stone-800">
                    {occ.name}
                  </h3>
                  <p className="text-stone-500 text-[11px] leading-relaxed mt-0.5 max-w-xs">
                    {occ.description}
                  </p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Right Column: Dynamic Florist Recommendations */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Main Card */}
          <div className="bg-white border border-stone-100 rounded-3xl p-6 sm:p-8 shadow-sm">
            
            <div className="flex items-center gap-2.5 mb-6">
              <span className="text-2xl">{selectedOccasion.emoji}</span>
              <div>
                <h2 className="font-serif text-lg sm:text-xl font-bold text-stone-800">
                  Recommended Recipe: {selectedOccasion.name}
                </h2>
                <p className="text-stone-400 text-xs">Recommended by our head floral designer</p>
              </div>
            </div>

            {/* Suggested Flowers Stems list */}
            <div className="bg-stone-50/60 border border-stone-100 rounded-2xl p-4.5 mb-6">
              <span className="text-[10px] font-mono text-stone-400 uppercase tracking-wider block mb-3">
                Must-Have Stems for this Theme
              </span>
              <div className="flex flex-wrap gap-2">
                {selectedOccasion.recommendedFlowers.map((stem, i) => (
                  <span 
                    key={i}
                    className="inline-flex items-center gap-1.5 bg-white border border-stone-200/50 text-stone-700 font-medium text-xs px-3 py-1.5 rounded-full shadow-2sm"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
                    {stem}
                  </span>
                ))}
              </div>
            </div>

            {/* Suggested Message templates */}
            <div className="space-y-4 mb-8">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-mono text-stone-400 uppercase tracking-wider">
                  Complimentary Greeting Cards Ideas
                </span>
                {copiedMessage && (
                  <span className="text-[10px] font-mono text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded animate-pulse">
                    Copied Message!
                  </span>
                )}
              </div>

              <div className="space-y-2.5">
                {selectedOccasion.messages.map((msg, index) => {
                  const isActive = activeMessage === msg;
                  return (
                    <div 
                      key={index}
                      className={`p-4 rounded-2xl border transition-all text-xs sm:text-sm leading-relaxed relative group cursor-pointer ${
                        isActive 
                          ? 'bg-amber-50/15 border-amber-200 text-stone-800 font-medium shadow-3sm' 
                          : 'bg-white border-stone-100 text-stone-500 hover:text-stone-700 hover:border-stone-150'
                      }`}
                      onClick={() => setActiveMessage(msg)}
                    >
                      <p className="pr-8">{msg}</p>
                      
                      {/* Actions */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleCopy(msg);
                        }}
                        className="absolute right-3.5 top-3.5 p-1.5 rounded-lg hover:bg-stone-100 text-stone-400 hover:text-stone-700 transition-colors cursor-pointer opacity-0 group-hover:opacity-100 focus:opacity-100"
                        title="Copy greeting to clipboard"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Customizer trigger wrapper */}
            <div className="border-t border-stone-100 pt-6 space-y-4">
              <h4 className="font-serif text-sm font-semibold text-stone-800">
                Ready to customize this theme?
              </h4>
              <p className="text-stone-500 text-xs sm:text-sm leading-relaxed">
                We'll pre-fill the flower builder workbench with a premium {recommendedBouquet?.name || 'custom base'}, select the ideal wrapping sheet, and write down your selected message of choice.
              </p>

              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  id="builder-prefill-btn"
                  onClick={() => onSelectOccasionPreset(recommendedBouquet, activeMessage)}
                  className="flex-1 py-3.5 px-6 rounded-2xl bg-amber-700 hover:bg-amber-800 text-white font-serif text-xs sm:text-sm font-semibold tracking-wide transition-all shadow-sm hover:scale-[1.01] active:translate-y-0 cursor-pointer flex items-center justify-center gap-2"
                >
                  <Gift className="w-4 h-4" />
                  Apply & Open In Workbench
                </button>
                <button
                  id="direct-shop-btn"
                  onClick={() => setActiveTab('shop')}
                  className="py-3.5 px-6 rounded-2xl border border-stone-200 hover:bg-stone-50 text-stone-700 font-serif text-xs sm:text-sm font-semibold tracking-wide transition-all cursor-pointer"
                >
                  Explore All Bouquets First
                </button>
              </div>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
}
