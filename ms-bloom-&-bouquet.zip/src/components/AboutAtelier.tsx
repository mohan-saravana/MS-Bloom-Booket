import React from 'react';
import { Compass, Heart, ShieldCheck, Sparkles, User, RefreshCw, Feather } from 'lucide-react';

export default function AboutAtelier() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in" id="about-atelier-workspace">
      
      {/* Page Title Header */}
      <div className="text-center mb-10">
        <span className="text-[11px] font-mono tracking-widest text-amber-600 uppercase bg-amber-50 px-3 py-1.5 rounded-full border border-amber-100 font-semibold inline-block mb-3">
          Our Brand Manifesto
        </span>
        <h1 className="font-serif text-3xl sm:text-4xl font-semibold text-stone-800 tracking-tight">
          About Our Floral Atelier
        </h1>
        <p className="text-stone-500 text-sm max-w-2xl mx-auto mt-2.5">
          Step into our creative sanctuary, where design thinking meets pure botanical poetry. We are on a mission to bring fresh, responsible floristry into Indian homes.
        </p>
      </div>

      {/* Grid Layout of brand values */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center mb-16">
        <div>
          <h2 className="font-serif text-xl sm:text-2xl font-bold text-stone-850 mb-4 leading-snug">
            Crafting Emotions, Stems, and Responsible Luxury Since 2021
          </h2>
          <p className="text-stone-600 text-xs sm:text-sm leading-relaxed mb-4">
            Our atelier was founded by master designers who felt that modern flower gifting was too cookie-cutter, over-wrapped in suffocating plastics, and disconnected from the natural beauty of individual botanical stems.
          </p>
          <p className="text-stone-600 text-xs sm:text-sm leading-relaxed mb-4">
            We source each single rose, lavender bud, and marigold cluster directly from ethical, family-owned high-altitude greenhouses in Pune, Ooty, and Kashmir. By bypassing traditional mandi auction warehouses, we offer premium shelf lives while paying fair compensation to local farmers.
          </p>
          <div className="border-l-2 border-amber-600 pl-4 py-1.5 my-5 bg-amber-50/30">
            <p className="font-serif text-xs sm:text-sm text-amber-900 font-medium italic">
              "Every bouquet is structured like a canvas painting — with focal elements, soft fillers, and supporting visual textures."
            </p>
            <span className="text-[10px] font-mono text-stone-400 block mt-1">— Ananya Sharma, Chief Florist Designer</span>
          </div>
        </div>

        {/* Brand visual grid */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-amber-50/50 border border-amber-200/45 p-6 rounded-3xl space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-white border border-stone-100 shadow-3sm flex items-center justify-center text-amber-700">
              <Feather className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-sm font-semibold text-stone-800">100% Zero-Plastic</h3>
            <p className="text-stone-500 text-[11px] leading-relaxed">
              We never use microplastic wraps, synthetic foam holders, or toxic glitter. Our packaging is made from compostable kraft paper and recycled cotton ribbons.
            </p>
          </div>

          <div className="bg-stone-50/70 border border-stone-200/40 p-6 rounded-3xl space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-white border border-stone-100 shadow-3sm flex items-center justify-center text-amber-700">
              <Compass className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-sm font-semibold text-stone-800">Fresh Farm-to-Vase</h3>
            <p className="text-stone-500 text-[11px] leading-relaxed">
              Our flowers travel in cold-chain trucks directly from farms to our workshop table. No intermediate storage means your blooms arrive in prime freshness.
            </p>
          </div>

          <div className="bg-stone-50/70 border border-stone-200/40 p-6 rounded-3xl space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-white border border-stone-100 shadow-3sm flex items-center justify-center text-amber-700">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-sm font-semibold text-stone-800">Masterful Floristry</h3>
            <p className="text-stone-500 text-[11px] leading-relaxed">
              Every customized bouquet is reviewed by an certified floral designer to ensure perfect weight balance, height proportions, and structural symmetry.
            </p>
          </div>

          <div className="bg-amber-50/50 border border-amber-200/45 p-6 rounded-3xl space-y-3">
            <div className="w-10 h-10 rounded-2xl bg-white border border-stone-100 shadow-3sm flex items-center justify-center text-amber-700">
              <Sparkles className="w-5 h-5" />
            </div>
            <h3 className="font-serif text-sm font-semibold text-stone-800">Fair Wages Sourced</h3>
            <p className="text-stone-500 text-[11px] leading-relaxed">
              We pay up to 40% above market rates for high-quality stems, which directly elevates rural farming households and community water-purification setups.
            </p>
          </div>
        </div>
      </div>

      {/* Sustainability Promise graphic block */}
      <div className="bg-stone-900 text-stone-100 rounded-3xl p-8 sm:p-12 relative overflow-hidden shadow-md">
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl" />
        
        <div className="max-w-3xl">
          <span className="text-[10px] font-mono tracking-widest text-amber-400 uppercase bg-stone-800 border border-stone-700 px-3 py-1 rounded-full mb-4 inline-block">
            Our Carbon Offset Promise
          </span>
          <h2 className="font-serif text-2xl sm:text-3xl font-bold tracking-tight mb-4">
            Every Hand-tied Order Plants a Native Tree
          </h2>
          <p className="text-stone-400 text-xs sm:text-sm leading-relaxed mb-6">
            In partnership with local forestry cooperatives, we plant native broadleaf saplings for every custom bouquet built and purchased. This absorbs the transport footprint of your fresh flower journey, keeping our business 100% net carbon-neutral.
          </p>
          <div className="flex flex-wrap gap-6 text-xs text-stone-300">
            <div className="flex items-center gap-2">
              <span className="text-amber-400 text-lg">✓</span>
              <span>10,400+ Trees Planted Since Launch</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-amber-400 text-lg">✓</span>
              <span>100% Recyclable Packaging Matrice</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-amber-400 text-lg">✓</span>
              <span>Sourced from Solar-powered Greenhouses</span>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}
