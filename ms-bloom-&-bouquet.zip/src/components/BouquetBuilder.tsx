import React, { useState, useEffect } from 'react';
import { Bouquet, Flower, WrappingType, CartItem } from '../types';
import { FLOWERS, WRAPPING_OPTIONS, BOUQUETS, getBouquetImage } from '../data';
import { Plus, Minus, ArrowLeft, Heart, Sparkles, MessageSquare, ShieldCheck, HelpCircle, Image as ImageIcon, Map as MapIcon } from 'lucide-react';

interface BouquetBuilderProps {
  initialBouquet: Bouquet | null;
  initialMessage?: string;
  onAddToCart: (cartItem: CartItem) => void;
  onCancel: () => void;
}

function VisualBlossom({ color, name }: { color: string; name: string }) {
  const isWhite = color === '#FFFFFF' || color === '#F9FAFB' || color === '#FEF3C7';
  let centerColor = '#F59E0B';
  if (color === '#DC2626') centerColor = '#FBBF24';
  if (color === '#EC4899') centerColor = '#FEF08A';
  if (isWhite) centerColor = '#FBBF24';
  if (color === '#A78BFA') centerColor = '#FDE047';
  
  return (
    <div className="relative w-10 h-10 flex items-center justify-center group cursor-pointer" title={name}>
      <div className="absolute w-8 h-8 rounded-full bg-stone-900/10 blur-[2px] translate-y-1 transition-transform group-hover:translate-y-1.5 duration-300" />
      <div className="absolute inset-0 flex items-center justify-center transition-transform duration-300 group-hover:rotate-12">
        {[0, 72, 144, 216, 288].map((angle, i) => (
          <div
            key={i}
            className="absolute w-4 h-9 rounded-full opacity-90 transition-all duration-300 group-hover:scale-105"
            style={{
              backgroundColor: color,
              transform: `rotate(${angle}deg) translateY(-6px)`,
              boxShadow: isWhite ? '0 1px 3px rgba(0,0,0,0.15), inset 0 -2px 4px rgba(0,0,0,0.05)' : 'inset 0 -2px 4px rgba(0,0,0,0.15)',
              border: isWhite ? '1px solid rgba(220, 220, 220, 0.6)' : '1px solid rgba(0,0,0,0.04)'
            }}
          />
        ))}
      </div>
      <div 
        className="absolute w-3 h-3 rounded-full shadow-md border border-white/40 flex items-center justify-center z-10 transition-transform duration-300 group-hover:scale-110"
        style={{ 
          backgroundColor: centerColor,
          boxShadow: 'inset 0 1px 2px rgba(255,255,255,0.4), 0 1px 2px rgba(0,0,0,0.1)'
        }}
      >
        <div className="w-1 h-1 bg-white/60 rounded-full" />
      </div>
    </div>
  );
}

export default function BouquetBuilder({ initialBouquet, initialMessage, onAddToCart, onCancel }: BouquetBuilderProps) {
  // If no bouquet is selected, let's start with a "Custom Masterpiece" from scratch
  const [selectedBase, setSelectedBase] = useState<Bouquet | null>(initialBouquet);
  const [addedFlowers, setAddedFlowers] = useState<{ [flowerId: string]: number }>({});
  const [selectedWrapping, setSelectedWrapping] = useState<WrappingType>('classic');
  const [cardMessage, setCardMessage] = useState<string>(initialMessage || '');
  const [isSuccessAnimated, setIsSuccessAnimated] = useState<boolean>(false);
  const [previewMode, setPreviewMode] = useState<'arrangement' | 'portrait'>('arrangement');

  // Sync selectedBase when initialBouquet prop changes
  useEffect(() => {
    setSelectedBase(initialBouquet);
  }, [initialBouquet]);

  // Set card message when initialMessage changes
  useEffect(() => {
    if (initialMessage) {
      setCardMessage(initialMessage);
    }
  }, [initialMessage]);

  // Load base bouquet's standard flowers on start or when base changes
  useEffect(() => {
    if (selectedBase) {
      const initialCounts: { [flowerId: string]: number } = {};
      selectedBase.baseFlowers.forEach(item => {
        initialCounts[item.flowerId] = item.count;
      });
      setAddedFlowers(initialCounts);
    } else {
      setAddedFlowers({});
    }
  }, [selectedBase]);

  // Adjust flower count
  const adjustFlowerCount = (flowerId: string, delta: number) => {
    setAddedFlowers(prev => {
      const current = prev[flowerId] || 0;
      const next = Math.max(0, current + delta);
      return { ...prev, [flowerId]: next };
    });
  };

  // Reset customized additions
  const handleReset = () => {
    if (selectedBase) {
      const initialCounts: { [flowerId: string]: number } = {};
      selectedBase.baseFlowers.forEach(item => {
        initialCounts[item.flowerId] = item.count;
      });
      setAddedFlowers(initialCounts);
    } else {
      setAddedFlowers({});
    }
    setSelectedWrapping('classic');
    setCardMessage('');
  };

  // Calculations
  const basePrice = selectedBase ? selectedBase.basePrice : 499; // ₹499 is base service & custom structure price
  const wrappingPrice = WRAPPING_OPTIONS.find(w => w.id === selectedWrapping)?.price || 0;
  
  // Calculate added flowers cost
  const flowersCostDetails = Object.entries(addedFlowers).map(([flowerId, count]) => {
    const flower = FLOWERS.find(f => f.id === flowerId);
    const pricePerStem = flower ? flower.price : 0;
    const countNum = Number(count);
    
    // If it started with a pre-made bouquet, the base flowers are already included in the base bouquet price.
    // We only charge for flowers added *beyond* the base bouquet's counts.
    let baseCount = 0;
    if (selectedBase) {
      const baseItem = selectedBase.baseFlowers.find(bf => bf.flowerId === flowerId);
      baseCount = baseItem ? baseItem.count : 0;
    }
    
    const extraStems = Math.max(0, countNum - baseCount);
    const cost = extraStems * pricePerStem;
    
    return {
      flower,
      count: countNum,
      extraStems,
      pricePerStem,
      cost
    };
  });

  const flowersTotalCost = flowersCostDetails.reduce((sum, item) => sum + item.cost, 0);
  const finalPrice = basePrice + flowersTotalCost + wrappingPrice;

  // Render a lovely visual array of flowers in the preview
  const visualFlowersList: { id: string; name: string; color: string }[] = [];
  Object.entries(addedFlowers).forEach(([flowerId, count]) => {
    const flower = FLOWERS.find(f => f.id === flowerId);
    const countNum = Number(count);
    if (flower) {
      for (let i = 0; i < countNum; i++) {
        visualFlowersList.push({
          id: `${flowerId}-${i}`,
          name: flower.name,
          color: flower.color
        });
      }
    }
  });

  // Handle Add to Cart
  const handleAddCustomToCart = () => {
    // Generate a unique card item ID
    const cartItemId = `cart-custom-${Date.now()}`;
    const cartItemName = selectedBase 
      ? `Customized ${selectedBase.name}` 
      : 'Bespoke Custom Bouquet';

    const cartItem: CartItem = {
      id: cartItemId,
      baseBouquet: selectedBase,
      name: cartItemName,
      addedFlowers: { ...addedFlowers },
      wrapping: selectedWrapping,
      cardMessage: cardMessage,
      quantity: 1,
      totalPrice: finalPrice
    };

    setIsSuccessAnimated(true);
    setTimeout(() => {
      onAddToCart(cartItem);
      setIsSuccessAnimated(false);
    }, 800);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in" id="bouquet-builder-panel">
      {/* Back navigation */}
      <button 
        id="builder-back-btn"
        onClick={onCancel}
        className="flex items-center gap-2 text-stone-500 hover:text-stone-800 transition-colors mb-6 text-sm font-medium cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Catalog
      </button>

      <div className="text-center mb-10">
        <span className="text-[11px] font-mono tracking-widest text-amber-600 uppercase bg-amber-50 px-3 py-1.5 rounded-full border border-amber-100 font-semibold inline-block mb-3">
          Florist Workbench
        </span>
        <h1 className="font-serif text-3xl sm:text-4xl font-semibold text-stone-800 tracking-tight">
          {selectedBase ? `Tailor Your ${selectedBase.name}` : 'Design a Bespoke Custom Bouquet'}
        </h1>
        <p className="text-stone-500 text-sm max-w-2xl mx-auto mt-2.5">
          {selectedBase 
            ? 'Add more roses, lilies, or hydrangeas to craft an even richer masterpiece. Watch the price update dynamically in real time.'
            : 'Select wrapper style, write your gift card message, and add your favorite stems. Custom structure setup fee is just ₹499.'}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* LEFT COLUMN: Visual Bouquet Simulator & Config */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Visual Canvas Card */}
          <div className="bg-stone-50/70 border border-stone-100 rounded-3xl p-6 relative overflow-hidden flex flex-col items-center">
            <span className="absolute top-4 left-4 text-[10px] font-mono text-stone-400 uppercase tracking-widest bg-white px-2.5 py-1 rounded-full border border-stone-100">
              Arrangement Preview
            </span>

            {/* Total Stems Count */}
            <span className="absolute top-4 right-4 text-[10px] font-mono text-stone-500 font-medium bg-amber-50 px-2.5 py-1 rounded-full border border-amber-100/60">
              {visualFlowersList.length} Stems Selected
            </span>

            {/* Preview Mode Switcher */}
            <div className="flex bg-stone-100 rounded-xl p-1 gap-1 mb-2 mt-12 z-10 border border-stone-200/40 shadow-inner">
              <button
                id="preview-mode-arrangement"
                type="button"
                onClick={() => setPreviewMode('arrangement')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-semibold transition-all cursor-pointer ${
                  previewMode === 'arrangement'
                    ? 'bg-white text-stone-800 shadow-2sm'
                    : 'text-stone-500 hover:text-stone-800'
                }`}
              >
                <MapIcon className="w-3.5 h-3.5" />
                Arrangement Map
              </button>
              <button
                id="preview-mode-portrait"
                type="button"
                onClick={() => setPreviewMode('portrait')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-semibold transition-all cursor-pointer ${
                  previewMode === 'portrait'
                    ? 'bg-white text-stone-800 shadow-2sm'
                    : 'text-stone-500 hover:text-stone-800'
                }`}
              >
                <ImageIcon className="w-3.5 h-3.5" />
                High-Fidelity Portrait
              </button>
            </div>

            {/* Vase/Wrapper Visual Container */}
            <div className="relative w-full h-[320px] flex items-end justify-center mt-2">
              
              {/* Decorative Flowers Canvas Area */}
              <div className="absolute inset-0 flex items-center justify-center pb-24 overflow-hidden">
                {previewMode === 'portrait' ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center pb-12">
                    <div className="relative w-44 h-44 rounded-full overflow-hidden border-4 border-white shadow-md bg-stone-100 transition-transform duration-500 hover:scale-105">
                      <img 
                        src={getBouquetImage(selectedBase, addedFlowers)} 
                        alt="Bouquet Portrait" 
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <span className="text-[10px] font-mono text-stone-400 mt-4 text-center px-4 leading-relaxed">
                      Portrait dynamically updates to reflect your dominant flower choices
                    </span>
                  </div>
                ) : (
                  visualFlowersList.length === 0 ? (
                    <div className="text-center text-stone-400 p-8">
                      <Heart className="w-8 h-8 mx-auto text-stone-300 stroke-[1.25] mb-2 animate-pulse" />
                      <p className="text-xs font-serif italic">Your bouquet is currently empty.</p>
                      <p className="text-[10px] font-mono mt-1">Add stems from the floristry list to begin</p>
                    </div>
                  ) : (
                    <div className="relative w-full h-full flex items-center justify-center">
                      {visualFlowersList.map((vf, index) => {
                        const theta = index * 137.5 * (Math.PI / 180);
                        const total = visualFlowersList.length;
                        const maxR = 95;
                        const r = Math.min(maxR, Math.sqrt(index + 1) * (total > 15 ? 16 : (total > 8 ? 19 : 23)));
                        const x = r * Math.cos(theta);
                        const y = r * Math.sin(theta) - 30;

                        return (
                          <div
                            key={vf.id}
                            className="absolute transition-all duration-500 ease-out hover:scale-125 z-10"
                            style={{
                              transform: `translate(${x}px, ${y}px)`,
                            }}
                          >
                            <VisualBlossom color={vf.color} name={vf.name} />
                          </div>
                        );
                      })}
                    </div>
                  )
                )}
              </div>

              {/* Bouquet Wrapper Graphic representation */}
              <div className="absolute bottom-2 z-10 w-[140px] h-[100px] bg-gradient-to-t from-amber-200/40 to-amber-100/20 rounded-b-full border border-amber-300/40 flex items-center justify-center overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-amber-400/40" />
                <div className="text-center font-mono text-[9px] uppercase tracking-wider text-amber-800/80 p-2 font-semibold">
                  {selectedWrapping === 'classic' && 'Pastel Kraft Wrap'}
                  {selectedWrapping === 'eco' && 'Rustic Kraft Jute'}
                  {selectedWrapping === 'silk' && 'Royal Organza Wrap'}
                </div>
              </div>

              {/* Decorative base ribbon bow */}
              <div className="absolute bottom-1 z-20 w-8 h-8 rounded-full bg-amber-600/90 flex items-center justify-center shadow-md animate-bounce">
                <div className="w-1.5 h-1.5 rounded-full bg-white" />
              </div>
            </div>

            {/* Simple switch bouquet source link */}
            <div className="w-full mt-4 pt-4 border-t border-stone-100 text-center">
              <span className="text-xs text-stone-500">
                Starting from:{' '}
                <strong className="font-medium text-stone-700">
                  {selectedBase ? selectedBase.name : 'Empty Canvas (Bespoke)'}
                </strong>
              </span>
              <button 
                id="toggle-base-btn"
                onClick={() => {
                  if (selectedBase) {
                    setSelectedBase(null);
                  } else {
                    setSelectedBase(BOUQUETS[0]);
                  }
                }}
                className="text-[11px] font-semibold text-amber-700 hover:text-amber-800 transition-colors underline block mx-auto mt-1 cursor-pointer"
              >
                {selectedBase ? 'Switch to Fully Custom' : 'Switch back to Premade Rose Base'}
              </button>
            </div>
          </div>

          {/* Wrapping Choice Card */}
          <div className="bg-white border border-stone-100 rounded-3xl p-6 shadow-sm">
            <h3 className="font-serif text-base font-semibold text-stone-800 mb-4 flex items-center gap-2">
              <Sparkles className="w-4.5 h-4.5 text-amber-600" />
              1. Choose Wrapping Style
            </h3>

            <div className="space-y-3">
              {WRAPPING_OPTIONS.map(option => (
                <label 
                  key={option.id}
                  id={`wrap-opt-${option.id}`}
                  className={`flex items-start gap-3 p-3.5 rounded-2xl border transition-all cursor-pointer ${
                    selectedWrapping === option.id 
                      ? 'bg-amber-50/50 border-amber-500/70 shadow-2sm' 
                      : 'border-stone-150 hover:bg-stone-50/50'
                  }`}
                >
                  <input
                    type="radio"
                    name="wrapping"
                    value={option.id}
                    checked={selectedWrapping === option.id}
                    onChange={() => setSelectedWrapping(option.id)}
                    className="mt-1 accent-amber-700 cursor-pointer h-4 w-4"
                  />
                  <div className="flex-grow">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-semibold text-stone-800">{option.name}</span>
                      <span className="text-xs font-semibold text-amber-900 bg-amber-100/50 px-2 py-0.5 rounded-lg">
                        +₹{option.price}
                      </span>
                    </div>
                    <p className="text-stone-500 text-[11px] leading-relaxed mt-1">
                      {option.description}
                    </p>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Greeting Card Message Box */}
          <div className="bg-white border border-stone-100 rounded-3xl p-6 shadow-sm">
            <h3 className="font-serif text-base font-semibold text-stone-800 mb-4 flex items-center gap-2">
              <MessageSquare className="w-4.5 h-4.5 text-amber-600" />
              2. Add a Custom Gift Message
            </h3>
            <textarea
              id="card-message-input"
              value={cardMessage}
              onChange={(e) => setCardMessage(e.target.value)}
              placeholder="Write a sweet birthday wish, anniversary note, or congratulatory message to print on our handcrafted floral stationery cards... (Complimentary)"
              className="w-full h-24 p-4 border border-stone-200 rounded-2xl text-stone-700 text-xs sm:text-sm placeholder-stone-400 focus:outline-none focus:ring-1 focus:ring-amber-600 focus:border-amber-600 resize-none leading-relaxed"
              maxLength={250}
            />
            <div className="text-right text-[10px] text-stone-400 font-mono mt-1">
              {cardMessage.length}/250 characters
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: Floristry Stem Selector & Dynamic Pricing */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Flower Selector Panel */}
          <div className="bg-white border border-stone-100 rounded-3xl p-6 shadow-sm">
            <div className="flex items-center justify-between border-b border-stone-100 pb-4 mb-5">
              <h2 className="font-serif text-lg font-semibold text-stone-800">
                3. Add More Flowers & Greenery
              </h2>
              <button 
                id="reset-builder-btn"
                onClick={handleReset}
                className="text-stone-400 hover:text-stone-700 text-xs transition-colors font-medium cursor-pointer"
              >
                Reset Additions
              </button>
            </div>

            {/* List of stems */}
            <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
              {FLOWERS.map(flower => {
                const count = addedFlowers[flower.id] || 0;
                
                // If starting with a pre-made bouquet, highlight the base quantity
                let baseCount = 0;
                if (selectedBase) {
                  const baseItem = selectedBase.baseFlowers.find(bf => bf.flowerId === flower.id);
                  baseCount = baseItem ? baseItem.count : 0;
                }
                const extraCount = Math.max(0, count - baseCount);

                return (
                  <div 
                    key={flower.id}
                    id={`flower-item-${flower.id}`}
                    className={`flex items-center justify-between p-3.5 rounded-2xl border transition-all ${
                      count > 0 
                        ? 'bg-amber-50/15 border-amber-200/50' 
                        : 'border-stone-100 hover:bg-stone-50/30'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {/* Color marker */}
                      <div 
                        className="w-4 h-4 rounded-full flex-shrink-0 border border-black/10 shadow-sm"
                        style={{ backgroundColor: flower.color }}
                      />
                      <div>
                        <div className="flex items-baseline gap-2">
                          <span className="text-sm font-semibold text-stone-800">{flower.name}</span>
                          <span className="text-stone-400 text-xs font-mono">₹{flower.price}/stem</span>
                        </div>
                        <p className="text-stone-500 text-[10px] sm:text-xs">
                          {flower.description}
                        </p>
                        {baseCount > 0 && (
                          <span className="inline-block mt-1 text-[9px] font-mono bg-stone-100 text-stone-600 px-2 py-0.5 rounded">
                            Standard Base Includes: {baseCount} Stems
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Quantity Controls */}
                    <div className="flex items-center gap-3 bg-stone-50 border border-stone-200/60 rounded-xl p-1.5 ml-3 flex-shrink-0">
                      <button
                        id={`minus-${flower.id}`}
                        onClick={() => adjustFlowerCount(flower.id, -1)}
                        className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors cursor-pointer ${
                          count > 0 
                            ? 'bg-white text-stone-700 hover:bg-stone-100 shadow-2sm' 
                            : 'text-stone-300 pointer-events-none'
                        }`}
                        disabled={count === 0}
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="w-6 text-center font-mono text-xs font-semibold text-stone-800">
                        {count}
                      </span>
                      <button
                        id={`plus-${flower.id}`}
                        onClick={() => adjustFlowerCount(flower.id, 1)}
                        className="w-7 h-7 bg-white text-stone-700 hover:bg-stone-100 rounded-lg flex items-center justify-center shadow-2sm transition-colors cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* DYNAMIC COST BILLING & BUY PREVIEW */}
          <div className="bg-gradient-to-br from-stone-900 to-stone-950 text-white rounded-3xl p-6 sm:p-8 shadow-lg relative overflow-hidden">
            {/* Background design elements */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl" />
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-rose-500/10 rounded-full blur-2xl" />

            <div className="relative">
              <span className="text-[9px] font-mono tracking-widest text-amber-400 uppercase font-semibold block mb-3">
                Live Cost Breakdown (Rupees Show in Buy)
              </span>
              
              <div className="space-y-3.5 border-b border-white/10 pb-5 mb-5 text-sm">
                
                {/* Base price row */}
                <div className="flex justify-between items-center text-stone-300">
                  <span className="font-serif">
                    {selectedBase ? `${selectedBase.name} (Base Bundle)` : 'Bespoke Structural Base Fee'}
                  </span>
                  <span className="font-mono text-white">₹{basePrice.toLocaleString('en-IN')}</span>
                </div>

                {/* Wrapping row */}
                <div className="flex justify-between items-center text-stone-300">
                  <span className="font-serif">Wrapping Choice ({WRAPPING_OPTIONS.find(w => w.id === selectedWrapping)?.name})</span>
                  <span className="font-mono text-white">₹{wrappingPrice.toLocaleString('en-IN')}</span>
                </div>

                {/* Added Flowers break down list */}
                {flowersCostDetails.filter(f => f.extraStems > 0).map(item => (
                  <div key={item.flower?.id} className="flex justify-between items-center text-stone-400 text-xs pl-3 border-l border-amber-500/30">
                    <span className="font-serif italic text-[11px] sm:text-xs">
                      + {item.extraStems} Extra {item.flower?.name} Stems (₹{item.pricePerStem}/each)
                    </span>
                    <span className="font-mono text-stone-300">₹{item.cost.toLocaleString('en-IN')}</span>
                  </div>
                ))}

                {/* If no extra flowers were added */}
                {flowersTotalCost === 0 && (
                  <div className="text-[11px] font-mono text-stone-500 pl-3">
                    No extra stems added yet. Standard flowers are bundled inside the base bouquet!
                  </div>
                )}
              </div>

              {/* Dynamic Grand Total */}
              <div className="flex items-center justify-between mb-6">
                <div>
                  <span className="text-stone-400 font-serif text-sm">Customized Bouquet Price</span>
                  <p className="text-[10px] font-mono text-stone-500">Including setup, wrapping, and stationery</p>
                </div>
                <div className="text-right">
                  <span className="text-2xl sm:text-3xl font-serif font-bold text-amber-400 tracking-tight">
                    ₹{finalPrice.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              {/* Terms Check */}
              <div className="flex items-center gap-2 mb-6 bg-white/5 p-3 rounded-2xl border border-white/5">
                <ShieldCheck className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                <span className="text-[10px] text-stone-300 leading-normal">
                  Our professional floral designers will hand-tie these additions seamlessly. Guaranteed fresh & lush on delivery.
                </span>
              </div>

              {/* Add to Cart button */}
              <button
                id="add-custom-to-cart-btn"
                onClick={handleAddCustomToCart}
                className={`w-full py-4 rounded-2xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-center font-serif font-semibold tracking-wide transition-all shadow-md active:translate-y-0 cursor-pointer flex items-center justify-center gap-2 hover:scale-[1.01] ${
                  isSuccessAnimated ? 'opacity-50 pointer-events-none bg-emerald-500 text-white' : ''
                }`}
              >
                {isSuccessAnimated ? (
                  <>
                    <Sparkles className="w-5 h-5 animate-spin" />
                    Adding to Bouquet Cart...
                  </>
                ) : (
                  <>
                    Add Customized Bouquet to Cart • ₹{finalPrice.toLocaleString('en-IN')}
                  </>
                )}
              </button>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
