import React, { useEffect, useRef } from 'react';

interface Petal {
  x: number;
  y: number;
  z: number;
  size: number;
  color: string;
  speedX: number;
  speedY: number;
  speedZ: number;
  rotX: number;
  rotY: number;
  rotZ: number;
  rotSpeedX: number;
  rotSpeedY: number;
  rotSpeedZ: number;
  opacity: number;
}

interface Pollen {
  x: number;
  y: number;
  z: number;
  size: number;
  speedX: number;
  speedY: number;
  speedZ: number;
  opacity: number;
}

interface BackgroundFlower {
  x: number;
  y: number;
  z: number;
  size: number;
  color: string;
  centerColor: string;
  petalCount: number;
  speedX: number;
  speedY: number;
  speedZ: number;
  rotX: number;
  rotY: number;
  rotZ: number;
  rotSpeedX: number;
  rotSpeedY: number;
  rotSpeedZ: number;
  opacity: number;
}

interface InteractiveFlower {
  x: number;
  y: number;
  size: number;
  targetSize: number;
  opacity: number;
  rotation: number;
  rotSpeed: number;
  petalCount: number;
  color: string;
  centerColor: string;
  age: number;
  maxAge: number;
}

export default function ThreeDBackground() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const mouseRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    // List of gorgeous floral colors matching MS Bloom & Bouquet (rose blush, gold, white, lavender)
    const PETAL_COLORS = [
      'rgba(244, 114, 182, 0.45)', // Pink carnation / rose blush
      'rgba(251, 113, 133, 0.4)',  // Soft coral / rose
      'rgba(253, 164, 175, 0.45)', // Pale rose peony
      'rgba(254, 243, 199, 0.5)',  // Pale lily cream
      'rgba(252, 211, 77, 0.35)',  // Yellow/gold marigold/sunflower glow
      'rgba(196, 181, 253, 0.4)'   // Soothing lavender tint
    ];

    // Flower-specific colors and centers
    const FLOWER_THEMES = [
      { color: 'rgba(239, 68, 68, 0.35)', centerColor: 'rgba(252, 211, 77, 0.7)' },   // Crimson / Gold Center
      { color: 'rgba(244, 114, 182, 0.35)', centerColor: 'rgba(254, 243, 199, 0.7)' }, // Sweet Pink / White Center
      { color: 'rgba(217, 70, 239, 0.35)', centerColor: 'rgba(251, 191, 36, 0.7)' },  // Purple Orchid / Gold Center
      { color: 'rgba(245, 158, 11, 0.35)', centerColor: 'rgba(120, 53, 4, 0.7)' },    // Marigold Orange / Dark Brown Center
      { color: 'rgba(59, 130, 246, 0.35)', centerColor: 'rgba(255, 255, 255, 0.8)' }   // Blue Hydrangea / White Center
    ];

    const petals: Petal[] = [];
    const pollens: Pollen[] = [];
    const bgFlowers: BackgroundFlower[] = [];
    const interactiveFlowers: InteractiveFlower[] = [];

    const pollenCount = 40;
    const petalCount = 18;
    const flowerCount = 12;

    // Camera settings
    const focalLength = 400;

    // Initialize Pollen (small glowing particles)
    for (let i = 0; i < pollenCount; i++) {
      pollens.push({
        x: Math.random() * width - width / 2,
        y: Math.random() * height - height / 2,
        z: Math.random() * 800 - 400,
        size: Math.random() * 2 + 1,
        speedX: (Math.random() - 0.5) * 0.4,
        speedY: Math.random() * 0.5 + 0.2,
        speedZ: (Math.random() - 0.5) * 0.2,
        opacity: Math.random() * 0.6 + 0.2
      });
    }

    // Initialize Petals (simulated 3D shapes)
    for (let i = 0; i < petalCount; i++) {
      petals.push({
        x: Math.random() * width - width / 2,
        y: Math.random() * height - height / 2,
        z: Math.random() * 600 - 300,
        size: Math.random() * 14 + 10,
        color: PETAL_COLORS[Math.floor(Math.random() * PETAL_COLORS.length)],
        speedX: (Math.random() - 0.3) * 0.6,
        speedY: Math.random() * 0.8 + 0.4,
        speedZ: (Math.random() - 0.5) * 0.3,
        rotX: Math.random() * Math.PI * 2,
        rotY: Math.random() * Math.PI * 2,
        rotZ: Math.random() * Math.PI * 2,
        rotSpeedX: (Math.random() - 0.5) * 0.02,
        rotSpeedY: (Math.random() - 0.5) * 0.015,
        rotSpeedZ: (Math.random() - 0.5) * 0.01,
        opacity: Math.random() * 0.5 + 0.3
      });
    }

    // Initialize 3D Floating Flower Blossoms
    for (let i = 0; i < flowerCount; i++) {
      const theme = FLOWER_THEMES[Math.floor(Math.random() * FLOWER_THEMES.length)];
      bgFlowers.push({
        x: Math.random() * width - width / 2,
        y: Math.random() * height - height / 2,
        z: Math.random() * 500 - 250,
        size: Math.random() * 18 + 18, // slightly larger than standard single petals
        color: theme.color,
        centerColor: theme.centerColor,
        petalCount: Math.random() > 0.5 ? 5 : 6, // elegant 5 or 6-petal blossoms
        speedX: (Math.random() - 0.4) * 0.4,
        speedY: Math.random() * 0.6 + 0.3,
        speedZ: (Math.random() - 0.5) * 0.2,
        rotX: Math.random() * Math.PI * 2,
        rotY: Math.random() * Math.PI * 2,
        rotZ: Math.random() * Math.PI * 2,
        rotSpeedX: (Math.random() - 0.5) * 0.015,
        rotSpeedY: (Math.random() - 0.5) * 0.01,
        rotSpeedZ: (Math.random() - 0.5) * 0.008,
        opacity: Math.random() * 0.45 + 0.25
      });
    }

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    const handleMouseMove = (e: MouseEvent) => {
      // Normalize to -0.5 to 0.5 range
      mouseRef.current.targetX = (e.clientX / window.innerWidth) - 0.5;
      mouseRef.current.targetY = (e.clientY / window.innerHeight) - 0.5;
    };

    const spawnInteractiveFlower = (clientX: number, clientY: number) => {
      // Gorgeous premium pink floral shades (rose blush, sweet pink, peony, hot pink, gold centers)
      const pinkColors = [
        'rgba(244, 114, 182, 0.75)', // pink-400
        'rgba(236, 72, 153, 0.7)',   // pink-500
        'rgba(251, 113, 133, 0.75)',  // rose-400
        'rgba(253, 164, 175, 0.8)',   // rose-300
        'rgba(244, 63, 94, 0.65)'     // rose-500
      ];
      const centers = [
        'rgba(251, 191, 36, 0.9)',   // gold
        'rgba(254, 240, 138, 0.95)', // yellow-200
        'rgba(255, 255, 255, 0.95)'  // pure white
      ];

      interactiveFlowers.push({
        x: clientX,
        y: clientY,
        size: 0,
        targetSize: Math.random() * 15 + 28, // beautifully proportioned bloom size (28px - 43px)
        opacity: 0.9,
        rotation: Math.random() * Math.PI * 2,
        rotSpeed: (Math.random() - 0.5) * 0.03,
        petalCount: Math.random() > 0.4 ? 5 : 6,
        color: pinkColors[Math.floor(Math.random() * pinkColors.length)],
        centerColor: centers[Math.floor(Math.random() * centers.length)],
        age: 0,
        maxAge: Math.random() * 30 + 45 // 45 to 75 frames lifetime
      });

      // Spawn 3 mini drifting petals from click site that blow away
      for (let i = 0; i < 3; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = Math.random() * 1.6 + 0.6;
        petals.push({
          x: clientX - window.innerWidth / 2,
          y: clientY - window.innerHeight / 2,
          z: Math.random() * 100 - 150, // closer depth plane so they drift beautifully
          size: Math.random() * 7 + 5,
          color: 'rgba(244, 114, 182, 0.85)', // rich pink petal
          speedX: Math.cos(angle) * speed,
          speedY: Math.sin(angle) * speed + 0.4, // float down with slight wind
          speedZ: (Math.random() - 0.5) * 0.4,
          rotX: Math.random() * Math.PI,
          rotY: Math.random() * Math.PI,
          rotZ: Math.random() * Math.PI,
          rotSpeedX: (Math.random() - 0.5) * 0.04,
          rotSpeedY: (Math.random() - 0.5) * 0.04,
          rotSpeedZ: (Math.random() - 0.5) * 0.04,
          opacity: 0.8
        });
      }
    };

    const handleWindowClick = (e: MouseEvent) => {
      spawnInteractiveFlower(e.clientX, e.clientY);
    };

    const handleWindowTouch = (e: TouchEvent) => {
      if (e.touches && e.touches[0]) {
        spawnInteractiveFlower(e.touches[0].clientX, e.touches[0].clientY);
      }
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleWindowClick);
    window.addEventListener('touchstart', handleWindowTouch);

    // Dynamic procedural flower rendering at origin
    const draw3DFlower = (c: CanvasRenderingContext2D, sz: number, col: string, cc: string, pC: number, op: number) => {
      c.save();
      
      // Render beautiful petal blades in a radial layout
      for (let j = 0; j < pC; j++) {
        const branchAngle = (j * Math.PI * 2) / pC;
        c.rotate(branchAngle);

        c.beginPath();
        c.moveTo(0, 0);
        // Teardrop organic petal curve
        c.bezierCurveTo(sz * 0.35, -sz * 0.5, sz * 0.45, -sz * 1.05, 0, -sz);
        c.bezierCurveTo(-sz * 0.45, -sz * 1.05, -sz * 0.35, -sz * 0.5, 0, 0);
        
        c.fillStyle = col;
        c.fill();

        // Subtle white inner highlight line (vein)
        c.beginPath();
        c.moveTo(0, 0);
        c.lineTo(0, -sz * 0.8);
        c.strokeStyle = `rgba(255, 255, 255, ${op * 0.3})`;
        c.lineWidth = 1;
        c.stroke();

        c.rotate(-branchAngle);
      }

      // Draw Flower Pistil / Core Disc
      c.beginPath();
      c.arc(0, 0, sz * 0.26, 0, Math.PI * 2);
      c.fillStyle = cc;
      c.fill();

      // Soft white sheen on the center disc
      c.beginPath();
      c.arc(0, 0, sz * 0.26, 0, Math.PI * 2);
      c.strokeStyle = `rgba(255, 255, 255, ${op * 0.4})`;
      c.lineWidth = 1;
      c.stroke();

      c.restore();
    };

    // Render loop
    const animate = () => {
      ctx.clearRect(0, 0, width, height);

      // Smooth mouse interpolation (Lerp) for camera rotation
      const mouse = mouseRef.current;
      mouse.x += (mouse.targetX - mouse.x) * 0.05;
      mouse.y += (mouse.targetY - mouse.y) * 0.05;

      // Draw glowing background radial gradient for extra luxury
      const radialGlow = ctx.createRadialGradient(
        width / 2 + mouse.x * 200,
        height / 2 + mouse.y * 200,
        10,
        width / 2,
        height / 2,
        Math.max(width, height) * 0.8
      );
      radialGlow.addColorStop(0, 'rgba(255, 253, 245, 0.45)'); // Warm amber interior glow
      radialGlow.addColorStop(0.6, 'rgba(255, 255, 255, 0)');
      radialGlow.addColorStop(1, 'rgba(250, 245, 233, 0.15)');
      ctx.fillStyle = radialGlow;
      ctx.fillRect(0, 0, width, height);

      const halfW = width / 2;
      const halfH = height / 2;

      // 1. Render and Update Pollens
      pollens.forEach((p) => {
        p.x += p.speedX + mouse.x * 1.5;
        p.y += p.speedY;
        p.z += p.speedZ;

        // Reset if goes off boundaries
        if (p.y > halfH) {
          p.y = -halfH - 20;
          p.x = Math.random() * width - halfW;
          p.z = Math.random() * 800 - 400;
        }
        if (p.x < -halfW - 100) p.x = halfW + 100;
        if (p.x > halfW + 100) p.x = -halfW - 100;

        const cosX = Math.cos(mouse.y * 0.2);
        const sinX = Math.sin(mouse.y * 0.2);
        const cosY = Math.cos(mouse.x * 0.2);
        const sinY = Math.sin(mouse.x * 0.2);

        let rotX1 = p.x * cosY - p.z * sinY;
        let rotZ1 = p.z * cosY + p.x * sinY;
        let rotY2 = p.y * cosX - rotZ1 * sinX;
        let rotZ2 = rotZ1 * cosX + p.y * sinX;

        const depth = rotZ2 + 500;
        if (depth > 50) {
          const scale = focalLength / depth;
          const projX = rotX1 * scale + halfW;
          const projY = rotY2 * scale + halfH;

          if (projX > -50 && projX < width + 50 && projY > -50 && projY < height + 50) {
            const currentSize = p.size * scale;
            const currentOpacity = Math.min(1, Math.max(0, p.opacity * scale * 1.2));

            ctx.save();
            ctx.beginPath();
            ctx.arc(projX, projY, currentSize, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(217, 119, 6, ${currentOpacity})`; // Amber-600 color
            ctx.shadowBlur = currentSize * 3;
            ctx.shadowColor = 'rgba(251, 191, 36, 0.8)';
            ctx.fill();
            ctx.restore();
          }
        }
      });

      // 2. Render and Update 3D Petals
      petals.forEach((p) => {
        p.x += p.speedX + mouse.x * 2.5;
        p.y += p.speedY;
        p.z += p.speedZ;

        p.rotX += p.rotSpeedX;
        p.rotY += p.rotSpeedY;
        p.rotZ += p.rotSpeedZ;

        if (p.y > halfH + 100) {
          p.y = -halfH - 100;
          p.x = Math.random() * width - halfW;
          p.z = Math.random() * 600 - 300;
        }
        if (p.x < -halfW - 200) p.x = halfW + 200;
        if (p.x > halfW + 200) p.x = -halfW - 200;

        const cosX = Math.cos(mouse.y * 0.15);
        const sinX = Math.sin(mouse.y * 0.15);
        const cosY = Math.cos(mouse.x * 0.15);
        const sinY = Math.sin(mouse.x * 0.15);

        let rotX1 = p.x * cosY - p.z * sinY;
        let rotZ1 = p.z * cosY + p.x * sinY;
        let rotY2 = p.y * cosX - rotZ1 * sinX;
        let rotZ2 = rotZ1 * cosX + p.y * sinX;

        const depth = rotZ2 + 500;
        if (depth > 50) {
          const scale = focalLength / depth;
          const projX = rotX1 * scale + halfW;
          const projY = rotY2 * scale + halfH;

          if (projX > -100 && projX < width + 100 && projY > -100 && projY < height + 100) {
            const size = p.size * scale;
            const opacity = Math.min(0.8, Math.max(0, p.opacity * scale));

            ctx.save();
            ctx.translate(projX, projY);
            ctx.rotate(p.rotZ);
            
            const scaleX = Math.cos(p.rotY);
            const scaleY = Math.sin(p.rotX);
            ctx.scale(scaleX, scaleY);

            ctx.beginPath();
            ctx.moveTo(0, -size);
            ctx.bezierCurveTo(size * 0.8, -size * 0.8, size * 0.6, size * 0.8, 0, size);
            ctx.bezierCurveTo(-size * 0.6, size * 0.8, -size * 0.8, -size * 0.8, 0, -size);

            const lightingGlow = Math.abs(scaleX * scaleY);
            ctx.fillStyle = p.color;
            ctx.fill();

            ctx.beginPath();
            ctx.moveTo(0, -size);
            ctx.quadraticCurveTo(size * 0.15, 0, 0, size);
            ctx.strokeStyle = `rgba(255, 255, 255, ${opacity * 0.4})`;
            ctx.lineWidth = 1;
            ctx.stroke();

            ctx.beginPath();
            ctx.arc(0, 0, size * 0.8, -Math.PI / 2, Math.PI / 2);
            ctx.strokeStyle = `rgba(255, 255, 255, ${opacity * 0.15 * lightingGlow})`;
            ctx.lineWidth = 1.5;
            ctx.stroke();

            ctx.restore();
          }
        }
      });

      // 3. Render and Update 3D Full Flower Blossoms
      bgFlowers.forEach((f) => {
        // Drift movement + wind response
        f.x += f.speedX + mouse.x * 2.0;
        f.y += f.speedY;
        f.z += f.speedZ;

        // Swirling pitch, yaw, and roll speeds
        f.rotX += f.rotSpeedX;
        f.rotY += f.rotSpeedY;
        f.rotZ += f.rotSpeedZ;

        // Reset / Loop recycle
        if (f.y > halfH + 120) {
          f.y = -halfH - 120;
          f.x = Math.random() * width - halfW;
          f.z = Math.random() * 500 - 250;
        }
        if (f.x < -halfW - 250) f.x = halfW + 250;
        if (f.x > halfW + 250) f.x = -halfW - 250;

        // Camera perspective matrices math
        const cosX = Math.cos(mouse.y * 0.12);
        const sinX = Math.sin(mouse.y * 0.12);
        const cosY = Math.cos(mouse.x * 0.12);
        const sinY = Math.sin(mouse.x * 0.12);

        let rotX1 = f.x * cosY - f.z * sinY;
        let rotZ1 = f.z * cosY + f.x * sinY;
        let rotY2 = f.y * cosX - rotZ1 * sinX;
        let rotZ2 = rotZ1 * cosX + f.y * sinX;

        const depth = rotZ2 + 500;
        if (depth > 50) {
          const scale = focalLength / depth;
          const projX = rotX1 * scale + halfW;
          const projY = rotY2 * scale + halfH;

          if (projX > -120 && projX < width + 120 && projY > -120 && projY < height + 120) {
            const size = f.size * scale;
            const opacity = Math.min(0.7, Math.max(0, f.opacity * scale));

            ctx.save();
            ctx.translate(projX, projY);
            
            // 3D Rotation matrices projected onto 2D viewport
            ctx.rotate(f.rotZ);
            const scaleX = Math.cos(f.rotY);
            const scaleY = Math.sin(f.rotX);
            ctx.scale(scaleX, scaleY);

            // Procedural call to render beautiful flower structures in scale
            draw3DFlower(ctx, size, f.color, f.centerColor, f.petalCount, opacity);

            ctx.restore();
          }
        }
      });

      // 4. Render and Update Interactive Pink Touch Flowers
      for (let i = interactiveFlowers.length - 1; i >= 0; i--) {
        const f = interactiveFlowers[i];
        f.age++;

        // Growing transition
        if (f.size < f.targetSize) {
          f.size += (f.targetSize - f.size) * 0.15;
        }

        // Fading transition
        if (f.age > f.maxAge * 0.5) {
          const fadeProgress = (f.age - f.maxAge * 0.5) / (f.maxAge * 0.5);
          f.opacity = Math.max(0, 0.9 * (1 - fadeProgress));
        }

        // Slight rotation spin
        f.rotation += f.rotSpeed;

        // Draw flower if opacity is active
        if (f.opacity > 0 && f.size > 0.5) {
          ctx.save();
          // Translate to absolute tap coordinates
          ctx.translate(f.x, f.y);
          ctx.rotate(f.rotation);

          // Draw petals
          for (let j = 0; j < f.petalCount; j++) {
            const branchAngle = (j * Math.PI * 2) / f.petalCount;
            ctx.rotate(branchAngle);

            ctx.beginPath();
            ctx.moveTo(0, 0);
            // Gorgeous plush petal lobe
            ctx.bezierCurveTo(f.size * 0.4, -f.size * 0.45, f.size * 0.55, -f.size * 1.0, 0, -f.size);
            ctx.bezierCurveTo(-f.size * 0.55, -f.size * 1.0, -f.size * 0.4, -f.size * 0.45, 0, 0);
            
            ctx.fillStyle = f.color.replace('0.75', f.opacity.toString()).replace('0.7', f.opacity.toString()).replace('0.8', f.opacity.toString()).replace('0.65', f.opacity.toString());
            ctx.fill();

            // Inner contrast highlight line (white vein)
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.lineTo(0, -f.size * 0.75);
            ctx.strokeStyle = `rgba(255, 255, 255, ${f.opacity * 0.35})`;
            ctx.lineWidth = 1;
            ctx.stroke();

            ctx.rotate(-branchAngle);
          }

          // Center pistil disc
          ctx.beginPath();
          ctx.arc(0, 0, f.size * 0.25, 0, Math.PI * 2);
          ctx.fillStyle = f.centerColor.replace('0.9', f.opacity.toString());
          ctx.fill();

          // Gold center glow outline
          ctx.beginPath();
          ctx.arc(0, 0, f.size * 0.25, 0, Math.PI * 2);
          ctx.strokeStyle = `rgba(255, 255, 255, ${f.opacity * 0.5})`;
          ctx.lineWidth = 1;
          ctx.stroke();

          ctx.restore();
        }

        // Remove dead flowers
        if (f.age >= f.maxAge) {
          interactiveFlowers.splice(i, 1);
        }
      }

      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleWindowClick);
      window.removeEventListener('touchstart', handleWindowTouch);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full pointer-events-none -z-10 bg-gradient-to-b from-stone-50/10 via-amber-50/5 to-stone-100/10"
      style={{ mixBlendMode: 'normal' }}
    />
  );
}
