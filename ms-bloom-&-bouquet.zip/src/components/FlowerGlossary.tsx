import React, { useState } from 'react';
import { FLOWERS } from '../data';
import { Flower } from '../types';
import { Sparkles, Heart, RefreshCw, Scissors, Compass, ShieldCheck } from 'lucide-react';

export default function FlowerGlossary() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Scent levels and meanings mapper helper
  const getFlowerDetails = (flowerId: string) => {
    switch (flowerId) {
      case 'red_rose':
        return {
          meaning: 'Eternal Love, Passion, and Courage',
          scent: 'High (Classic Sweet Rose)',
          lifespan: '7 - 10 Days',
          origin: 'Ooty Highlands, Tamil Nadu',
          humidity: 'Moderate'
        };
      case 'pink_rose':
        return {
          meaning: 'Grace, Elegance, Gentleness, and Happiness',
          scent: 'Medium-High (Fresh Rose)',
          lifespan: '7 - 10 Days',
          origin: 'Pune Hills, Maharashtra',
          humidity: 'Moderate'
        };
      case 'white_rose':
        return {
          meaning: 'Purity, New Beginnings, and Heavenly Grace',
          scent: 'Medium (Clean Petals)',
          lifespan: '7 - 10 Days',
          origin: 'Pune Hills, Maharashtra',
          humidity: 'Moderate'
        };
      case 'sunflower':
        return {
          meaning: 'Adoration, Loyalty, Happiness, and Warmth',
          scent: 'Low (Earthy Seed)',
          lifespan: '8 - 12 Days',
          origin: 'Bellary Plains, Karnataka',
          humidity: 'Low'
        };
      case 'white_lily':
        return {
          meaning: 'Majesty, Royal Honor, and Rebirth',
          scent: 'Very High (Sweet Jasmine Musk)',
          lifespan: '9 - 13 Days',
          origin: 'Kodaikanal Valley, India',
          humidity: 'High'
        };
      case 'blue_hydrangea':
        return {
          meaning: 'Heartfelt Apology, Abundance, and Gratitude',
          scent: 'Mild (Light Ozone)',
          lifespan: '5 - 7 Days',
          origin: 'Munnar Hills, Kerala',
          humidity: 'Very High (Needs misting)'
        };
      case 'pink_carnation':
        return {
          meaning: 'Motherly Affection, Pure Admiration, and Remembrance',
          scent: 'Medium (Clove Spicy Sweet)',
          lifespan: '12 - 16 Days (Longest-lasting!)',
          origin: 'Solan Slopes, Himachal Pradesh',
          humidity: 'Low'
        };
      case 'lavender_stem':
        return {
          meaning: 'Tranquility, Restfulness, Healing, and Grace',
          scent: 'Extremely High (Soothing Herbal)',
          lifespan: '14+ Days (Great for drying)',
          origin: 'Kashmir Lavender Meadows',
          humidity: 'Dry'
        };
      case 'babys_breath':
        return {
          meaning: 'Everlasting Sincere Love and Pure Innocence',
          scent: 'Low',
          lifespan: '10 - 14 Days',
          origin: 'Nilgiri Valley, Tamil Nadu',
          humidity: 'Low'
        };
      case 'eucalyptus':
        return {
          meaning: 'Rejuvenation, Scent Protection, and Clarity',
          scent: 'High (Minty Herbal)',
          lifespan: '15+ Days',
          origin: 'Coonoor Forests, India',
          humidity: 'Dry'
        };
      case 'solidago':
        return {
          meaning: 'Wealth, Good Luck, and Cheerful Success',
          scent: 'Low (Wildflower Honey)',
          lifespan: '9 - 12 Days',
          origin: 'Dehradun Foothills, India',
          humidity: 'Moderate'
        };
      case 'orange_gerbera':
        return {
          meaning: 'Absolute Sunshine, Friendliness, and Positivity',
          scent: 'Low',
          lifespan: '8 - 11 Days',
          origin: 'Bangalore Greenhouse Valley',
          humidity: 'Moderate'
        };
      case 'yellow_tulip':
        return {
          meaning: 'Cheerful Thoughts, Bright Rays, and Affection',
          scent: 'Mild (Fruity Crisp)',
          lifespan: '6 - 8 Days',
          origin: 'Srinagar Gardens, Jammu & Kashmir',
          humidity: 'High'
        };
      case 'purple_orchid':
        return {
          meaning: 'Imperial Royalty, Wealth, Luxury, and Rare Grace',
          scent: 'Medium (Exotic Vanilla-Orchid)',
          lifespan: '14 - 18 Days',
          origin: 'Kalimpong Foothills, West Bengal',
          humidity: 'High'
        };
      case 'red_anthurium':
        return {
          meaning: 'Hospitality, Abundant Good Luck, and Deep Passion',
          scent: 'Mild',
          lifespan: '16 - 21 Days (Highly Durable)',
          origin: 'Sikkim Organic Greenhouses',
          humidity: 'High'
        };
      case 'pink_peony':
        return {
          meaning: 'Prosperity, Joyous Romance, and Beautiful Fortune',
          scent: 'High (Plush Nectar Sweet)',
          lifespan: '5 - 7 Days (Delicate)',
          origin: 'Srinagar Premium Gardens',
          humidity: 'Moderate'
        };
      case 'marigold_stem':
        return {
          meaning: 'Auspicious Joy, Devotion, Sacred Warmth, and Optimism',
          scent: 'High (Spicy Earthy Musky)',
          lifespan: '10 - 14 Days',
          origin: 'Nashik Plains, Maharashtra',
          humidity: 'Moderate'
        };
      default:
        return {
          meaning: 'Sincere Joy and Florist Craftsmanship',
          scent: 'Mild',
          lifespan: '7 - 10 Days',
          origin: 'Local Greenhouse Sourced',
          humidity: 'Moderate'
        };
    }
  };

  // Filter list
  const filteredFlowers = FLOWERS.filter(f => {
    const matchesSearch = f.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          f.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || f.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in" id="flower-glossary-workspace">
      
      {/* Page Title Header */}
      <div className="text-center mb-10">
        <span className="text-[11px] font-mono tracking-widest text-amber-600 uppercase bg-amber-50 px-3 py-1.5 rounded-full border border-amber-100 font-semibold inline-block mb-3">
          Floriculture Dictionary
        </span>
        <h1 className="font-serif text-3xl sm:text-4xl font-semibold text-stone-800 tracking-tight">
          Flower Glossary & Stem Care
        </h1>
        <p className="text-stone-500 text-sm max-w-2xl mx-auto mt-2.5">
          Learn the emotional meanings, scent intensities, origins, and care protocols for each blossom. Knowledge makes your bouquet gift even more meaningful.
        </p>
      </div>

      {/* CORE CARE TIPS PANEL (Staggered Card) */}
      <div className="bg-gradient-to-br from-amber-50 to-amber-100/30 border border-amber-200/50 rounded-3xl p-6 sm:p-8 shadow-sm mb-12 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-40 h-40 bg-amber-200/20 rounded-full blur-2xl" />
        
        <h2 className="font-serif text-lg sm:text-xl font-bold text-stone-800 mb-5 flex items-center gap-2">
          <Scissors className="w-5 h-5 text-amber-700 animate-pulse" />
          Pro Care Guide: How to Make Your Flowers Last Longer
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 text-xs sm:text-sm">
          <div className="space-y-1.5">
            <span className="font-mono text-amber-700 font-bold block">01. 45° Stem Trim</span>
            <p className="text-stone-600 leading-relaxed text-xs">
              Always trim the stems by 1-2 cm at a sharp 45-degree angle underwater. This maximizes the water-absorbing surface area and prevents air blockages in the tubes.
            </p>
          </div>
          <div className="space-y-1.5">
            <span className="font-mono text-amber-700 font-bold block">02. Fresh Cold Water</span>
            <p className="text-stone-600 leading-relaxed text-xs">
              Change the vase water fully every 2 days. Use cold or lukewarm tap water. Clean water stops bacterial growth, which is the main reason flowers wilt early.
            </p>
          </div>
          <div className="space-y-1.5">
            <span className="font-mono text-amber-700 font-bold block">03. Strip Low Foliage</span>
            <p className="text-stone-600 leading-relaxed text-xs">
              Remove any leaves on the stems that would sit below the water level. Leaves decaying inside vase water create immediate toxic bacteria that decay stems.
            </p>
          </div>
          <div className="space-y-1.5">
            <span className="font-mono text-amber-700 font-bold block">04. Avoid Fruit Bowls</span>
            <p className="text-stone-600 leading-relaxed text-xs">
              Keep your gorgeous bouquet away from ripening fruits (especially bananas and apples), which emit invisible ethylene gas that rapidly ages and kills flower petals.
            </p>
          </div>
        </div>
      </div>

      {/* SEARCH AND FILTERS PANEL */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-stone-150 pb-5 mb-8">
        <div>
          <h2 className="font-serif text-lg font-semibold text-stone-850">
            Meet Our 17 Signature Botanicals
          </h2>
          <p className="text-stone-400 text-xs mt-0.5">
            Hover to explore symbolism and geographic origin across Indian farms
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto justify-end">
          <div className="flex items-center bg-stone-100/80 p-1 rounded-xl border border-stone-200/50">
            {['all', 'focal', 'premium', 'filler', 'greenery'].map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs tracking-wide font-serif capitalize transition-all cursor-pointer ${
                  selectedCategory === cat 
                    ? 'bg-white text-amber-900 font-semibold shadow-2sm' 
                    : 'text-stone-500 hover:text-stone-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <input
            type="text"
            placeholder="Search flower glossary..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="px-3.5 py-1.5 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-700 bg-white placeholder-stone-400 focus:outline-none focus:ring-1 focus:ring-amber-600 focus:border-amber-600"
          />
        </div>
      </div>

      {/* CARD GRID LAYOUT */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredFlowers.map((flower) => {
          const details = getFlowerDetails(flower.id);
          return (
            <div 
              key={flower.id}
              id={`glossary-card-${flower.id}`}
              className="bg-white rounded-3xl border border-stone-100 shadow-2sm hover:shadow-md transition-all p-6 flex flex-col justify-between"
            >
              <div>
                {/* Header info */}
                <div className="flex justify-between items-start gap-3 mb-4">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-5 h-5 rounded-full border border-black/10 shadow-sm" 
                      style={{ backgroundColor: flower.color }}
                    />
                    <h3 className="font-serif text-base font-bold text-stone-850">
                      {flower.name}
                    </h3>
                  </div>
                  <span className="text-[10px] font-mono tracking-widest uppercase bg-stone-50 text-stone-400 border border-stone-150/60 px-2.5 py-1 rounded-full">
                    {flower.category}
                  </span>
                </div>

                <p className="text-stone-500 text-xs sm:text-sm leading-relaxed mb-4">
                  {flower.description}
                </p>

                {/* Technical botanical specifications */}
                <div className="space-y-2 border-t border-stone-100 pt-4 text-xs">
                  
                  <div className="flex justify-between">
                    <span className="text-stone-400 font-medium">Spiritual Symbolism</span>
                    <span className="text-amber-900 font-serif font-medium max-w-[180px] text-right">
                      {details.meaning}
                    </span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-stone-400">Aroma Level</span>
                    <span className="text-stone-700 font-medium">{details.scent}</span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-stone-400">Expected Vase Life</span>
                    <span className="text-stone-700 font-mono font-medium">{details.lifespan}</span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-stone-400">Cultivated Origin</span>
                    <span className="text-stone-700 font-medium">{details.origin}</span>
                  </div>

                </div>
              </div>

              {/* Price show in buy notation */}
              <div className="mt-5 pt-3 border-t border-stone-100 flex items-center justify-between">
                <span className="text-[10px] font-mono text-stone-400 uppercase tracking-widest">
                  Workbench Price per Stem
                </span>
                <span className="font-serif text-sm font-bold text-amber-950 bg-amber-50 border border-amber-100/50 px-2 py-0.5 rounded-lg">
                  ₹{flower.price}
                </span>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
}
