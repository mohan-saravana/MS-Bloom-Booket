import React, { useState, useEffect } from 'react';
import { Bouquet, CartItem, Order, OrderStatus } from './types';
import { BOUQUETS } from './data';
import Header from './components/Header';
import BouquetCard from './components/BouquetCard';
import BouquetBuilder from './components/BouquetBuilder';
import CartView from './components/CartView';
import OrdersHistory from './components/OrdersHistory';
import OccasionsGuide from './components/OccasionsGuide';
import FlowerGlossary from './components/FlowerGlossary';
import AboutAtelier from './components/AboutAtelier';
import ThreeDBackground from './components/ThreeDBackground';
import { Sparkles, Flower, Calendar, ArrowRight, Heart, ShieldCheck } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'shop' | 'builder' | 'cart' | 'orders' | 'occasions' | 'glossary' | 'about'>('shop');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [selectedBouquetToCustomize, setSelectedBouquetToCustomize] = useState<Bouquet | null>(null);
  const [selectedPresetMessage, setSelectedPresetMessage] = useState<string>('');
  
  // Search and Filter States for the shop
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Load cart and orders from localStorage on start
  useEffect(() => {
    const savedCart = localStorage.getItem('bloom_atelier_cart');
    const savedOrders = localStorage.getItem('bloom_atelier_orders');
    if (savedCart) {
      try {
        setCart(JSON.parse(savedCart));
      } catch (e) {
        console.error('Error loading cart', e);
      }
    }
    if (savedOrders) {
      try {
        setOrders(JSON.parse(savedOrders));
      } catch (e) {
        console.error('Error loading orders', e);
      }
    }
  }, []);

  // Save cart to localStorage
  const saveCart = (newCart: CartItem[]) => {
    setCart(newCart);
    localStorage.setItem('bloom_atelier_cart', JSON.stringify(newCart));
  };

  // Save orders to localStorage
  const saveOrders = (newOrders: Order[]) => {
    setOrders(newOrders);
    localStorage.setItem('bloom_atelier_orders', JSON.stringify(newOrders));
  };

  // Triggered when clicking "Customize Bouquet" or "Add More Flowers"
  const handleCustomizeInit = (bouquet: Bouquet) => {
    setSelectedBouquetToCustomize(bouquet);
    setSelectedPresetMessage('');
    setActiveTab('builder');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Triggered from Gift Finder / Occasions presets page
  const handleSelectOccasionPreset = (baseBouquet: Bouquet | null, presetMessage: string) => {
    setSelectedBouquetToCustomize(baseBouquet);
    setSelectedPresetMessage(presetMessage);
    setActiveTab('builder');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Triggered when clicking "Buy Directly" from catalogue
  const handleBuyDirectly = (bouquet: Bouquet) => {
    // Generate a default cart item with no extra flowers
    const baseFlowersCount: { [flowerId: string]: number } = {};
    bouquet.baseFlowers.forEach(bf => {
      baseFlowersCount[bf.flowerId] = bf.count;
    });

    const cartItemId = `cart-direct-${bouquet.id}-${Date.now()}`;
    const directCartItem: CartItem = {
      id: cartItemId,
      baseBouquet: bouquet,
      name: bouquet.name,
      addedFlowers: baseFlowersCount,
      wrapping: 'classic',
      cardMessage: '',
      quantity: 1,
      totalPrice: bouquet.basePrice
    };

    // Check if a standard direct-buy of the exact same bouquet already exists, if so merge quantity
    const existingIndex = cart.findIndex(item => 
      item.baseBouquet?.id === bouquet.id && 
      item.wrapping === 'classic' && 
      item.cardMessage === '' && 
      Object.keys(item.addedFlowers).length === Object.keys(baseFlowersCount).length &&
      Object.entries(item.addedFlowers).every(([fId, val]) => baseFlowersCount[fId] === val)
    );

    if (existingIndex > -1) {
      const updatedCart = [...cart];
      updatedCart[existingIndex].quantity += 1;
      saveCart(updatedCart);
    } else {
      saveCart([...cart, directCartItem]);
    }

    // Direct user straight to cart/checkout workspace
    setActiveTab('cart');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Triggered from builder when finished configuring custom bouquet
  const handleAddCustomToCart = (customCartItem: CartItem) => {
    saveCart([...cart, customCartItem]);
    setSelectedBouquetToCustomize(null);
    setActiveTab('cart');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Update quantity in shopping cart
  const handleUpdateCartQuantity = (id: string, delta: number) => {
    const updatedCart = cart.map(item => {
      if (item.id === id) {
        const nextQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: nextQty };
      }
      return item;
    });
    saveCart(updatedCart);
  };

  // Delete item from shopping cart
  const handleRemoveCartItem = (id: string) => {
    const updatedCart = cart.filter(item => item.id !== id);
    saveCart(updatedCart);
  };

  // Final order placements
  const handlePlaceOrder = (newOrder: Order) => {
    saveOrders([newOrder, ...orders]);
    saveCart([]); // clear cart
  };

  // Development simulation for testing order updates
  const handleUpdateOrderStatus = (orderId: string, nextStatus: OrderStatus) => {
    const updatedOrders = orders.map(order => {
      if (order.id === orderId) {
        return { ...order, status: nextStatus };
      }
      return order;
    });
    saveOrders(updatedOrders);
  };

  // Count items in cart
  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  // Filter bouquets for catalog
  const filteredBouquets = BOUQUETS.filter(b => {
    const matchesSearch = b.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          b.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || b.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-stone-50/25 text-stone-800 flex flex-col font-sans selection:bg-amber-100 selection:text-amber-900 relative">
      
      {/* 3D Animated Interactive Floating Petals Background */}
      <ThreeDBackground />
      
      {/* Dynamic Header Component */}
      <Header 
        activeTab={activeTab} 
        setActiveTab={(tab) => {
          setActiveTab(tab);
          // When switching back to builder, clean initial custom pointer if clicked manually
          if (tab !== 'builder') {
            setSelectedBouquetToCustomize(null);
          }
        }} 
        cartCount={totalCartCount} 
      />

      {/* Main Content Workspace */}
      <main className="flex-grow">
        {activeTab === 'shop' && (
          <div className="space-y-12">
            
            {/* Elegant Hero Banner */}
            <section className="bg-gradient-to-b from-amber-50/75 via-amber-50/20 to-transparent pt-12 pb-16 border-b border-stone-100/50">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
                
                {/* Floating floral details */}
                <div className="absolute top-0 left-10 text-amber-200/50 animate-pulse hidden lg:block">
                  <Flower className="w-12 h-12 stroke-[1.25]" />
                </div>
                <div className="absolute bottom-6 right-20 text-rose-200/50 animate-bounce hidden lg:block">
                  <Flower className="w-10 h-10 stroke-[1]" />
                </div>

                <span className="text-[11px] font-mono tracking-widest text-amber-700 uppercase bg-amber-100/50 px-3.5 py-1.5 rounded-full border border-amber-200/50 font-semibold inline-block mb-4">
                  Fresh Handcrafted Blooms Direct To Your Door
                </span>
                
                <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-extrabold text-stone-850 tracking-tight leading-[1.1] max-w-4xl mx-auto">
                  Aesthetic Bouquets Crafted For Precious Moments
                </h1>
                
                <p className="text-stone-500 text-sm sm:text-base max-w-2xl mx-auto mt-4.5 leading-relaxed">
                  Select an artisan premade bouquet, or customize your own by adding premium roses, lilies, baby's breath, and bespoke wrapping. Calculations instantly update in Rupees (₹) below.
                </p>

                {/* Hero Feature Badges */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto mt-10">
                  <div className="bg-white/80 border border-stone-100 p-4 rounded-2xl shadow-2sm">
                    <span className="font-serif text-lg font-bold text-amber-900 block">₹0 Delivery</span>
                    <p className="text-[10px] text-stone-400 font-mono uppercase mt-1">Orders Above ₹1,500</p>
                  </div>
                  <div className="bg-white/80 border border-stone-100 p-4 rounded-2xl shadow-2sm">
                    <span className="font-serif text-lg font-bold text-amber-900 block">100% Fresh</span>
                    <p className="text-[10px] text-stone-400 font-mono uppercase mt-1">Sourced Daily From Farms</p>
                  </div>
                  <div className="bg-white/80 border border-stone-100 p-4 rounded-2xl shadow-2sm">
                    <span className="font-serif text-lg font-bold text-amber-900 block">Tailored Recipe</span>
                    <p className="text-[10px] text-stone-400 font-mono uppercase mt-1">Add Stems Individually</p>
                  </div>
                  <div className="bg-white/80 border border-stone-100 p-4 rounded-2xl shadow-2sm">
                    <span className="font-serif text-lg font-bold text-amber-900 block">Express Track</span>
                    <p className="text-[10px] text-stone-400 font-mono uppercase mt-1">Real-Time Delivery Stages</p>
                  </div>
                </div>

                {/* Instant customizable shortcut call to action */}
                <div className="mt-10">
                  <button
                    id="hero-go-builder"
                    onClick={() => {
                      setSelectedBouquetToCustomize(null);
                      setActiveTab('builder');
                    }}
                    className="inline-flex items-center gap-2 py-3.5 px-7 rounded-2xl bg-stone-900 hover:bg-stone-850 text-amber-400 font-serif font-semibold text-sm tracking-wide transition-all shadow-md hover:scale-[1.02] cursor-pointer"
                  >
                    Launch Custom Workbench
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </section>

            {/* Catalog Grid Section with Search / Filters */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
              
              {/* Search & Filter Header Bar */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-stone-150 pb-5 mb-8">
                <div>
                  <h2 className="font-serif text-xl sm:text-2xl font-semibold text-stone-850">
                    Artisan Signature Catalogue
                  </h2>
                  <p className="text-stone-400 text-xs mt-0.5">
                    Choose a starter theme or checkout instantly
                  </p>
                </div>

                {/* Filter and Search Container */}
                <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto justify-end">
                  {/* Category select buttons */}
                  <div className="flex items-center bg-stone-100/80 p-1 rounded-xl border border-stone-200/50">
                    {['all', 'romantic', 'cheerful', 'elegant', 'exotic'].map(cat => (
                      <button
                        key={cat}
                        id={`filter-cat-${cat}`}
                        onClick={() => setSelectedCategory(cat)}
                        className={`px-3 py-1.5 rounded-lg text-xs tracking-wide font-serif capitalize transition-all cursor-pointer ${
                          selectedCategory === cat 
                            ? 'bg-white text-amber-900 font-semibold shadow-2sm' 
                            : 'text-stone-500 hover:text-stone-800'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>

                  {/* Search input */}
                  <input
                    type="text"
                    id="catalog-search"
                    placeholder="Search bouquets..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="px-3.5 py-1.5 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-700 bg-white placeholder-stone-400 focus:outline-none focus:ring-1 focus:ring-amber-600 focus:border-amber-600 max-w-[180px]"
                  />
                </div>
              </div>

              {/* Grid Catalog */}
              {filteredBouquets.length === 0 ? (
                <div className="text-center py-16 bg-white rounded-3xl border border-stone-100/60 p-8">
                  <p className="text-stone-500 text-sm">No bouquets matched your criteria.</p>
                  <button 
                    onClick={() => { setSearchQuery(''); setSelectedCategory('all'); }} 
                    className="text-xs text-amber-700 font-semibold underline mt-2 block mx-auto cursor-pointer"
                  >
                    Clear Search Filters
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
                  {filteredBouquets.map(bouquet => (
                    <BouquetCard 
                      key={bouquet.id} 
                      bouquet={bouquet} 
                      onCustomize={handleCustomizeInit}
                      onAddToCart={handleBuyDirectly}
                    />
                  ))}
                </div>
              )}
            </section>

          </div>
        )}

        {activeTab === 'builder' && (
          <BouquetBuilder 
            initialBouquet={selectedBouquetToCustomize}
            initialMessage={selectedPresetMessage}
            onAddToCart={handleAddCustomToCart}
            onCancel={() => {
              setSelectedBouquetToCustomize(null);
              setSelectedPresetMessage('');
              setActiveTab('shop');
            }}
          />
        )}

        {activeTab === 'occasions' && (
          <OccasionsGuide 
            onSelectOccasionPreset={handleSelectOccasionPreset}
            setActiveTab={setActiveTab}
          />
        )}

        {activeTab === 'glossary' && (
          <FlowerGlossary />
        )}

        {activeTab === 'about' && (
          <AboutAtelier />
        )}

        {activeTab === 'cart' && (
          <CartView 
            cart={cart}
            onUpdateQuantity={handleUpdateCartQuantity}
            onRemoveItem={handleRemoveCartItem}
            onPlaceOrder={handlePlaceOrder}
            setActiveTab={setActiveTab}
          />
        )}

        {activeTab === 'orders' && (
          <OrdersHistory 
            orders={orders}
            onUpdateOrderStatus={handleUpdateOrderStatus}
            setActiveTab={setActiveTab}
          />
        )}
      </main>

      {/* Elegant Footer */}
      <footer className="bg-stone-900 text-stone-300 py-12 border-t border-stone-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-3.5 col-span-1 md:col-span-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-amber-500/15 flex items-center justify-center text-amber-400">
                  <Flower className="w-4.5 h-4.5" />
                </div>
                <span className="font-serif text-lg tracking-wide font-bold text-white">
                  MS Bloom & Bouquet
                </span>
              </div>
              <p className="text-stone-400 text-xs sm:text-sm max-w-sm leading-relaxed">
                Hand-tied luxury bouquets arranged with care by master artisans. Customize your bouquet recipe by adding more stems directly from the workbench. Complete secure purchase in Rupees (₹).
              </p>
            </div>

            <div>
              <h3 className="text-white font-serif text-sm font-semibold mb-3">Our Services</h3>
              <ul className="space-y-2 text-xs text-stone-400">
                <li><button onClick={() => setActiveTab('shop')} className="hover:text-amber-400 transition-colors">Artisan Bouquet Shop</button></li>
                <li><button onClick={() => { setSelectedBouquetToCustomize(null); setActiveTab('builder'); }} className="hover:text-amber-400 transition-colors">Custom Bouquet Builder</button></li>
                <li><button onClick={() => setActiveTab('occasions')} className="hover:text-amber-400 transition-colors">Gift Finder by Occasion</button></li>
                <li><button onClick={() => setActiveTab('glossary')} className="hover:text-amber-400 transition-colors">Botanical Stem Glossary</button></li>
                <li><button onClick={() => setActiveTab('about')} className="hover:text-amber-400 transition-colors">About Our Atelier</button></li>
                <li><button onClick={() => setActiveTab('orders')} className="hover:text-amber-400 transition-colors">Real-Time Tracker</button></li>
              </ul>
            </div>

            <div className="space-y-3">
              <h3 className="text-white font-serif text-sm font-semibold">Store Credentials</h3>
              <div className="space-y-1.5 text-xs text-stone-400 font-mono">
                <div className="flex gap-2 items-center">
                  <Calendar className="w-3.5 h-3.5 text-amber-500" />
                  <span>Open Mon - Sun: 7 AM - 9 PM</span>
                </div>
                <div className="flex gap-2 items-center">
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />
                  <span>Secure Local SSL Gateway</span>
                </div>
                <p className="text-[10px] text-stone-500 pt-1 border-t border-stone-800">
                  Calculations and transactions made purely in Indian Rupees (₹).
                </p>
              </div>
            </div>
          </div>

          <div className="border-t border-stone-800 mt-10 pt-6 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-stone-500">
            <p>© {new Date().getFullYear()} MS Bloom & Bouquet Ltd. All rights reserved.</p>
            <div className="flex gap-4">
              <span className="hover:text-stone-300 cursor-pointer">Privacy Policy</span>
              <span className="hover:text-stone-300 cursor-pointer">Terms of Service</span>
              <span className="hover:text-stone-300 cursor-pointer">Refund Guidelines</span>
            </div>
          </div>
        </div>
      </footer>

    </div>
  );
}
