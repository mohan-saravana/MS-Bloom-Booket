import { Flower, Bouquet, WrappingOption } from './types';

export const FLOWERS: Flower[] = [
  {
    id: 'red_rose',
    name: 'Red Rose',
    category: 'focal',
    price: 120,
    color: '#DC2626',
    description: 'The ultimate symbol of deep love and classic elegance.'
  },
  {
    id: 'pink_rose',
    name: 'Blush Pink Rose',
    category: 'focal',
    price: 120,
    color: '#EC4899',
    description: 'Expresses grace, gratitude, and gentle affection.'
  },
  {
    id: 'white_rose',
    name: 'Snow White Rose',
    category: 'focal',
    price: 120,
    color: '#F9FAFB',
    description: 'Represents purity, youthfulness, and fresh beginnings.'
  },
  {
    id: 'sunflower',
    name: 'Golden Sunflower',
    category: 'focal',
    price: 150,
    color: '#EAB308',
    description: 'Radiates joy, loyalty, and bright positivity.'
  },
  {
    id: 'white_lily',
    name: 'Royal White Lily',
    category: 'premium',
    price: 220,
    color: '#FEF3C7',
    description: 'Magnificent, highly fragrant blossoms signifying royalty.'
  },
  {
    id: 'blue_hydrangea',
    name: 'Blue Hydrangea',
    category: 'premium',
    price: 280,
    color: '#60A5FA',
    description: 'Lush, cloud-like clusters expressing heartfelt gratitude.'
  },
  {
    id: 'pink_carnation',
    name: 'Pink Carnation',
    category: 'focal',
    price: 70,
    color: '#F472B6',
    description: 'Expresses motherly love, gratitude, and admiration.'
  },
  {
    id: 'lavender_stem',
    name: 'French Lavender Stem',
    category: 'filler',
    price: 80,
    color: '#A78BFA',
    description: 'Soothing aroma and delicate purple hues.'
  },
  {
    id: 'babys_breath',
    name: "Baby's Breath",
    category: 'filler',
    price: 50,
    color: '#FFFFFF',
    description: 'Tiny white blossoms creating a soft, misty background.'
  },
  {
    id: 'eucalyptus',
    name: 'Silver Eucalyptus',
    category: 'greenery',
    price: 40,
    color: '#6B7280',
    description: 'Silver-green leaves that add volume and a fresh scent.'
  },
  {
    id: 'solidago',
    name: 'Golden Solidago',
    category: 'greenery',
    price: 60,
    color: '#FACC15',
    description: 'Vibrant yellow filler stems adding warmth and texture.'
  },
  {
    id: 'orange_gerbera',
    name: 'Orange Gerbera Daisy',
    category: 'focal',
    price: 90,
    color: '#F97316',
    description: 'Bold and playful daisy that radiates absolute happiness.'
  },
  {
    id: 'yellow_tulip',
    name: 'Golden Tulip',
    category: 'focal',
    price: 110,
    color: '#FBBF24',
    description: 'Delicate spring blossom representing cheerful thoughts.'
  },
  {
    id: 'purple_orchid',
    name: 'Imperial Purple Orchid',
    category: 'premium',
    price: 210,
    color: '#8B5CF6',
    description: 'Rare, elegant tropical stem symbolizing luxury and rare beauty.'
  },
  {
    id: 'red_anthurium',
    name: 'Crimson Anthurium',
    category: 'premium',
    price: 180,
    color: '#EF4444',
    description: 'Heart-shaped exotic flower adding high-end drama.'
  },
  {
    id: 'pink_peony',
    name: 'Blossoming Pink Peony',
    category: 'premium',
    price: 340,
    color: '#FDA4AF',
    description: 'Ultra-plush layers representing prosperity and good fortune.'
  },
  {
    id: 'marigold_stem',
    name: 'Golden Marigold (Genda) Stem',
    category: 'filler',
    price: 45,
    color: '#F59E0B',
    description: 'Festive yellow-orange blossoms bringing auspicious traditional warmth.'
  }
];

export const BOUQUETS: Bouquet[] = [
  {
    id: 'blushing_romance',
    name: 'Blushing Romance Bouquet',
    description: 'A luxurious hand-tied arrangement of blush pink roses, soft pink carnations, and delicate white baby\'s breath. The absolute language of love and tenderness.',
    basePrice: 1299,
    imageUrl: '/src/assets/images/bouquet_roses_1782414790938.jpg',
    category: 'romantic',
    baseFlowers: [
      { flowerId: 'pink_rose', count: 6 },
      { flowerId: 'pink_carnation', count: 4 },
      { flowerId: 'babys_breath', count: 3 },
      { flowerId: 'eucalyptus', count: 2 }
    ]
  },
  {
    id: 'golden_grace',
    name: 'Golden Grace Sunflower Bouquet',
    description: 'Bring radiant sunshine into their day with vibrant golden sunflowers, sprays of yellow solidago, and fresh green eucalyptus leaves.',
    basePrice: 999,
    imageUrl: '/src/assets/images/bouquet_sunflowers_1782414806667.jpg',
    category: 'cheerful',
    baseFlowers: [
      { flowerId: 'sunflower', count: 5 },
      { flowerId: 'solidago', count: 4 },
      { flowerId: 'eucalyptus', count: 3 }
    ]
  },
  {
    id: 'royal_lily',
    name: 'Royal Lily Elegance Bouquet',
    description: 'Exquisite and fragrant large white lilies paired with pristine white roses and silver dollar eucalyptus. Perfect for sophisticated moments.',
    basePrice: 1499,
    imageUrl: '/src/assets/images/bouquet_lilies_1782414822705.jpg',
    category: 'elegant',
    baseFlowers: [
      { flowerId: 'white_lily', count: 4 },
      { flowerId: 'white_rose', count: 6 },
      { flowerId: 'eucalyptus', count: 4 }
    ]
  },
  {
    id: 'mystic_meadow',
    name: 'Mystic Meadow Lavender Bouquet',
    description: 'A dreamy, mystical bouquet of dry French lavender stems, white and purple roses, and soft blue hydrangea blooms, bound with delicate ribbons.',
    basePrice: 1399,
    imageUrl: '/src/assets/images/bouquet_lavender_1782414837926.jpg',
    category: 'exotic',
    baseFlowers: [
      { flowerId: 'lavender_stem', count: 8 },
      { flowerId: 'blue_hydrangea', count: 2 },
      { flowerId: 'white_rose', count: 4 },
      { flowerId: 'eucalyptus', count: 2 }
    ]
  }
];

export const WRAPPING_OPTIONS: WrappingOption[] = [
  {
    id: 'classic',
    name: 'Premium Pastel Wrapping & Ribbon',
    price: 150,
    description: 'Elegantly wrapped in water-resistant matte florist sheet and tied with a thick double-faced satin ribbon.'
  },
  {
    id: 'eco',
    name: 'Rustic Eco-Kraft & Jute Twine',
    price: 100,
    description: 'Sustainable, organic brown kraft paper bound together with raw, natural jute twine for an organic, rustic feel.'
  },
  {
    id: 'silk',
    name: 'Luxury Royal Silk & Organza Wrap',
    price: 250,
    description: 'Enwrapped in premium woven organza and silk sheets, finished with a golden metallic double-bow.'
  }
];

export function getBouquetImage(baseBouquet: Bouquet | null, addedFlowers: { [flowerId: string]: number }): string {
  // Count by color category
  let yellowCount = 0; // sunflower, solidago, marigold_stem, yellow_tulip, orange_gerbera
  let purpleCount = 0; // lavender_stem, purple_orchid, blue_hydrangea
  let whiteCount = 0;  // white_rose, white_lily, babys_breath
  let redPinkCount = 0; // red_rose, pink_rose, pink_carnation, red_anthurium, pink_peony

  Object.entries(addedFlowers).forEach(([flowerId, count]) => {
    const num = Number(count);
    if (num <= 0) return;

    // Retrieve the flower object to see its properties
    const flower = FLOWERS.find(f => f.id === flowerId);
    if (!flower) return;

    // Skip greenery (like eucalyptus) entirely so it doesn't skew color categorization
    if (flower.category === 'greenery') return;

    if (['sunflower', 'solidago', 'marigold_stem', 'yellow_tulip', 'orange_gerbera'].includes(flowerId)) {
      yellowCount += num;
    } else if (['lavender_stem', 'purple_orchid', 'blue_hydrangea'].includes(flowerId)) {
      purpleCount += num;
    } else if (['white_rose', 'white_lily', 'babys_breath'].includes(flowerId)) {
      whiteCount += num;
    } else if (['red_rose', 'pink_rose', 'pink_carnation', 'red_anthurium', 'pink_peony'].includes(flowerId)) {
      redPinkCount += num;
    }
  });

  const max = Math.max(yellowCount, purpleCount, whiteCount, redPinkCount);

  if (max === 0) {
    if (baseBouquet) return baseBouquet.imageUrl;
    return '/src/assets/images/bouquet_roses_1782414790938.jpg';
  }

  if (yellowCount === max) {
    return '/src/assets/images/bouquet_sunflowers_1782414806667.jpg';
  }
  if (whiteCount === max) {
    return '/src/assets/images/bouquet_lilies_1782414822705.jpg';
  }
  if (purpleCount === max) {
    return '/src/assets/images/bouquet_lavender_1782414837926.jpg';
  }

  return '/src/assets/images/bouquet_roses_1782414790938.jpg';
}

