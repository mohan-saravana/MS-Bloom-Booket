export interface Flower {
  id: string;
  name: string;
  category: 'focal' | 'filler' | 'greenery' | 'premium';
  price: number; // in Rupees (₹)
  color: string;
  description: string;
}

export interface BaseFlowerItem {
  flowerId: string;
  count: number;
}

export interface Bouquet {
  id: string;
  name: string;
  description: string;
  basePrice: number; // in Rupees (₹)
  imageUrl: string;
  baseFlowers: BaseFlowerItem[];
  category: 'romantic' | 'cheerful' | 'elegant' | 'exotic';
}

export type WrappingType = 'classic' | 'eco' | 'silk';

export interface WrappingOption {
  id: WrappingType;
  name: string;
  price: number; // in Rupees (₹)
  description: string;
}

export interface CartItem {
  id: string;
  baseBouquet: Bouquet | null; // null if fully custom from scratch
  name: string;
  addedFlowers: { [flowerId: string]: number }; // flowerId -> count added
  wrapping: WrappingType;
  cardMessage: string;
  quantity: number;
  totalPrice: number; // in Rupees (₹)
}

export type OrderStatus = 'placed' | 'assembling' | 'dispatched' | 'delivered';

export interface Order {
  id: string;
  items: CartItem[];
  customerName: string;
  deliveryAddress: string;
  phoneNumber: string;
  cardMessage: string;
  subtotal: number;
  deliveryFee: number;
  total: number;
  status: OrderStatus;
  orderDate: string;
  deliveryDate: string;
}
